﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class EXPENSE_REPORT : Form
    {
        public EXPENSE_REPORT()
        {
            InitializeComponent();
        }

        private void EXPENSE_REPORT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.SupplierOrder' table. You can move, or remove it, as needed.
            this.SupplierOrderTableAdapter.Fill(this.group12DataSet.SupplierOrder);
            // TODO: This line of code loads data into the 'group12DataSet.Employee' table. You can move, or remove it, as needed.
            this.EmployeeTableAdapter.Fill(this.group12DataSet.Employee);
            // TODO: This line of code loads data into the 'group12DataSet.SupplierOrder' table. You can move, or remove it, as needed.
            this.supplierOrderTableAdapter1.Fill(this.group12DataSet.SupplierOrder);
            // TODO: This line of code loads data into the 'group12DataSet.Employee' table. You can move, or remove it, as needed.
            this.supplierTableAdapter1.Fill(this.group12DataSet.Supplier);
            this.ExpenseReport2.SetDataSource(group12DataSet);
            this.crystalReportViewer1.RefreshReport();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
