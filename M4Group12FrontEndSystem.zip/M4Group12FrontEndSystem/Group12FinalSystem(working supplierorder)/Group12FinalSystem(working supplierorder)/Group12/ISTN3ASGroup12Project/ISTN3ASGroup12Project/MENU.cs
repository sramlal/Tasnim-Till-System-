﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class MENU : Form
    {
        public MENU()
        {
            InitializeComponent();
            menuSupplier.Enabled = false;
            menuReports.Enabled = false;
            menuStaff.Enabled = false;
            menuSales.Enabled = false;
            menuCustomer.Enabled = false;
            menuInventory.Enabled = false;
            menuInvoices.Enabled = false;
        }

        private void menuLogin_Click(object sender, EventArgs e)
        {
            Form login = new LOGIN();
            login.MdiParent = this;
            login.Show();
        }

        private void menuSupplier_Click(object sender, EventArgs e)
        {
            
        }

        private void menuSuppEditSupplierDatabase_Click(object sender, EventArgs e)
        {
            Form supplier = new SUPPLIER();
            PrepareForm(supplier);
        }

        private void menuSuppEditOrderDatabase_Click(object sender, EventArgs e)
        {
            Form supplyOrder = new ORDER();
            PrepareForm(supplyOrder);
        }

        private void menuReports_Click(object sender, EventArgs e)
        {

        }

        private void menuRepSales_Click(object sender, EventArgs e)
        {
            Form salesReport = new SALES_REPORT();
            PrepareForm(salesReport);
        }

        private void menuRepExpenses_Click(object sender, EventArgs e)
        {
            Form expenseReport = new EXPENSE_REPORT();
            PrepareForm(expenseReport);
        }

        private void menuRepStaff_Click(object sender, EventArgs e)
        {
            Form staffReport = new STAFF_REPORT();
            PrepareForm(staffReport);
        }

        private void menuRepInventory_Click(object sender, EventArgs e)
        {
            Form invReport = new INVENTORY_REPORT();
            PrepareForm(invReport);
        }

        private void menuRepSupplier_Click(object sender, EventArgs e)
        {
            Form suppReport = new SUPPLIER_REPORT();
            PrepareForm(suppReport);
        }

        private void menuRepCustomer_Click(object sender, EventArgs e)
        {
            Form custReport = new CUSTOMER_REPORT();
            PrepareForm(custReport);
        }

        private void menuStaff_Click(object sender, EventArgs e)
        {

        }

        private void menuStaffEditStaffDatabase_Click(object sender, EventArgs e)
        {
            Form staff = new STAFF();
            PrepareForm(staff);
        }

        private void menuSales_Click(object sender, EventArgs e)
        {

        }

        private void menuSalesEditSalesDatabase_Click(object sender, EventArgs e)
        {
            Form processTransact = new PROCESSTRANSACTION();
            PrepareForm(processTransact);
        }

        private void menuCustomer_Click(object sender, EventArgs e)
        {

        }

        private void menuCustEditCustomerDatabase_Click(object sender, EventArgs e)
        {
            Form customer = new CUSTOMER();
            PrepareForm(customer);
        }

        private void menuInventory_Click(object sender, EventArgs e)
        {

        }

        private void menuInvEditInventoryDatabase_Click(object sender, EventArgs e)
        {
            Form inventory = new INVENTORY();
            PrepareForm(inventory);
        }

        private void menuTBLoginStatus_Click(object sender, EventArgs e)
        {

        }

        private void menuInvoices_Click(object sender, EventArgs e)
        {

        }

        private void menuInvSupplyInvoice_Click(object sender, EventArgs e)
        {
            Form invoice = new INVOICE();
            PrepareForm(invoice);
        }

        private void CloseChild()
        {
            foreach( Form f in this.MdiChildren)
            {
                f.Close();
            }
        }

        private void PrepareForm(Form myform)
        {
            CloseChild();
            myform.MdiParent = this;
            myform.WindowState = FormWindowState.Maximized;
            myform.Show();
        }

        private void menuLogout_Click(object sender, EventArgs e)
        {

        }

        private void menuLogoutExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void menuLOLogout_Click(object sender, EventArgs e)
        {
            CloseChild();
            menuLogin.Enabled = true;
            menuSupplier.Enabled = false;
            menuReports.Enabled = false;
            menuStaff.Enabled = false;
            menuSales.Enabled = false;
            menuCustomer.Enabled = false;
            menuInventory.Enabled = false;
            menuInvoices.Enabled = false;

            menuTBLoginStatus.Text = "logged out";
        }

        private void MENU_Load(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form help = new HELP();
            PrepareForm(help);
        }
    }
}
