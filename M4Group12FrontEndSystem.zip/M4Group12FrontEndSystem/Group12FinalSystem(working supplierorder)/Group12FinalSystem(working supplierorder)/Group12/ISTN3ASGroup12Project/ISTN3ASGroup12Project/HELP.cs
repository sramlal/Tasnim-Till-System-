﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class HELP : Form
    {
        public HELP()
        {
            InitializeComponent();
            comboBox1.Items.Add("Login");
            comboBox1.Items.Add("Suppliers");
            comboBox1.Items.Add("Reports");
            comboBox1.Items.Add("Staff");
            comboBox1.Items.Add("Sales");
            comboBox1.Items.Add("Customer");
            comboBox1.Items.Add("Inventory");
            comboBox1.Items.Add("Invoices");
            comboBox1.Items.Add("Log Out");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int page = comboBox1.SelectedIndex;

            switch (page)
            {
                case 0:
                    string login = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\login.txt");
                    richTextBox1.Text = (login);
                    break;

                case 1:
                    string suppliers = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\supplier.txt");
                    richTextBox1.Text = (suppliers);
                    break;

                case 2:
                    string reports = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\reports.txt");
                    richTextBox1.Text = (reports);
                    break;

                case 3:
                    string staff = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\staff.txt");
                    richTextBox1.Text = (staff);
                    break;

                case 4:
                    string sales = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\Sale.txt");
                    richTextBox1.Text = (sales);
                    break;

                case 5:
                    string customer = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\customer.txt");
                    richTextBox1.Text = (customer);
                    break;

                case 6:
                    string inventory = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\inventory.txt");
                    richTextBox1.Text = (inventory);
                    break;

                case 7:
                    string invoices = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\invoices.txt");
                    richTextBox1.Text = (invoices);
                    break;

                case 8:
                    string logOut = System.IO.File.ReadAllText(@"C:\Users\Rayen Pillay\Desktop\Group12FinalSystem(working supplierorder)\Group12FinalSystem(working supplierorder)\Group12\ISTN3ASGroup12Project\ISTN3ASGroup12Project\Help\logOut.txt");
                    richTextBox1.Text = (logOut);
                    break;

                default:
                    break;
            }
        }
    }
}
