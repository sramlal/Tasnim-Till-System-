﻿
namespace ISTN3ASGroup12Project
{
    partial class PROCESSTRANSACTION
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PROCESSTRANSACTION));
            this.orderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSales = new ISTN3ASGroup12Project.group12DataSet();
            this.itemListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taSalesDb = new ISTN3ASGroup12Project.group12DataSetTableAdapters.OrderTableAdapter();
            this.taSaleItemsDb = new ISTN3ASGroup12Project.group12DataSetTableAdapters.ItemListTableAdapter();
            this.taCustID = new ISTN3ASGroup12Project.group12DataSetTableAdapters.CustomerTableAdapter();
            this.taAddSale = new ISTN3ASGroup12Project.group12DataSetTableAdapters.OrderTableAdapter();
            this.taFindInv = new ISTN3ASGroup12Project.group12DataSetTableAdapters.InventoryTableAdapter();
            this.taAddSaleItem = new ISTN3ASGroup12Project.group12DataSetTableAdapters.ItemListTableAdapter();
            this.taUpdateTotalDue = new ISTN3ASGroup12Project.group12DataSetTableAdapters.OrderTableAdapter();
            this.taUpdateCostOfSale = new ISTN3ASGroup12Project.group12DataSetTableAdapters.OrderTableAdapter();
            this.inventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.taSearchTPINV = new ISTN3ASGroup12Project.group12DataSetTableAdapters.InventoryTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.orderIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custIDNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOfSaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentTypeDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.discountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costOfSaleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btAddSale = new System.Windows.Forms.Button();
            this.cbDiscount = new System.Windows.Forms.ComboBox();
            this.cbPaymentType = new System.Windows.Forms.ComboBox();
            this.tbEmpID = new System.Windows.Forms.TextBox();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbCustID = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAddSaleItem = new System.Windows.Forms.Button();
            this.tbQuant = new System.Windows.Forms.TextBox();
            this.tbDescrip = new System.Windows.Forms.TextBox();
            this.tbItemPrice = new System.Windows.Forms.TextBox();
            this.tbInvID = new System.Windows.Forms.TextBox();
            this.tbOrderID = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.itemIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventoryIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.tbInvSearch = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.inventoryIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invSellingPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invQuantityAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btCompTrans = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.tbOrderIDComp = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.taEmpLogin = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.employeeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSales)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // orderBindingSource
            // 
            this.orderBindingSource.DataMember = "Order";
            this.orderBindingSource.DataSource = this.dsSales;
            // 
            // dsSales
            // 
            this.dsSales.DataSetName = "group12DataSet";
            this.dsSales.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemListBindingSource
            // 
            this.itemListBindingSource.DataMember = "ItemList";
            this.itemListBindingSource.DataSource = this.dsSales;
            // 
            // taSalesDb
            // 
            this.taSalesDb.ClearBeforeFill = true;
            // 
            // taSaleItemsDb
            // 
            this.taSaleItemsDb.ClearBeforeFill = true;
            // 
            // taCustID
            // 
            this.taCustID.ClearBeforeFill = true;
            // 
            // taAddSale
            // 
            this.taAddSale.ClearBeforeFill = true;
            // 
            // taFindInv
            // 
            this.taFindInv.ClearBeforeFill = true;
            // 
            // taAddSaleItem
            // 
            this.taAddSaleItem.ClearBeforeFill = true;
            // 
            // taUpdateTotalDue
            // 
            this.taUpdateTotalDue.ClearBeforeFill = true;
            // 
            // taUpdateCostOfSale
            // 
            this.taUpdateCostOfSale.ClearBeforeFill = true;
            // 
            // inventoryBindingSource
            // 
            this.inventoryBindingSource.DataMember = "Inventory";
            this.inventoryBindingSource.DataSource = this.dsSales;
            // 
            // taSearchTPINV
            // 
            this.taSearchTPINV.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.btAddSale);
            this.groupBox1.Controls.Add(this.cbDiscount);
            this.groupBox1.Controls.Add(this.cbPaymentType);
            this.groupBox1.Controls.Add(this.tbEmpID);
            this.groupBox1.Controls.Add(this.tbCustID);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1276, 275);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ADD A SALE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1238, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 34;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Enter Customer and Employee ID, Select A Payment Type, Discount Amount Then Add S" +
        "ale To Database");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(822, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "DISCOUNT AMOUNT:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(569, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "PAYMENT TYPE:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(318, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "EMPLOYEE ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "CUSTOMER ID:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIDDataGridViewTextBoxColumn,
            this.custIDNoDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.dateOfSaleDataGridViewTextBoxColumn,
            this.totalDueDataGridViewTextBoxColumn,
            this.paymentTypeDataGridViewCheckBoxColumn,
            this.discountDataGridViewTextBoxColumn,
            this.costOfSaleDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.orderBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(3, 77);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1270, 195);
            this.dataGridView1.TabIndex = 5;
            // 
            // orderIDDataGridViewTextBoxColumn
            // 
            this.orderIDDataGridViewTextBoxColumn.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn.Name = "orderIDDataGridViewTextBoxColumn";
            // 
            // custIDNoDataGridViewTextBoxColumn
            // 
            this.custIDNoDataGridViewTextBoxColumn.DataPropertyName = "CustIDNo";
            this.custIDNoDataGridViewTextBoxColumn.HeaderText = "CustIDNo";
            this.custIDNoDataGridViewTextBoxColumn.Name = "custIDNoDataGridViewTextBoxColumn";
            this.custIDNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            // 
            // dateOfSaleDataGridViewTextBoxColumn
            // 
            this.dateOfSaleDataGridViewTextBoxColumn.DataPropertyName = "DateOfSale";
            this.dateOfSaleDataGridViewTextBoxColumn.HeaderText = "DateOfSale";
            this.dateOfSaleDataGridViewTextBoxColumn.Name = "dateOfSaleDataGridViewTextBoxColumn";
            // 
            // totalDueDataGridViewTextBoxColumn
            // 
            this.totalDueDataGridViewTextBoxColumn.DataPropertyName = "TotalDue";
            this.totalDueDataGridViewTextBoxColumn.HeaderText = "TotalDue";
            this.totalDueDataGridViewTextBoxColumn.Name = "totalDueDataGridViewTextBoxColumn";
            // 
            // paymentTypeDataGridViewCheckBoxColumn
            // 
            this.paymentTypeDataGridViewCheckBoxColumn.DataPropertyName = "PaymentType";
            this.paymentTypeDataGridViewCheckBoxColumn.HeaderText = "PaymentType";
            this.paymentTypeDataGridViewCheckBoxColumn.Name = "paymentTypeDataGridViewCheckBoxColumn";
            // 
            // discountDataGridViewTextBoxColumn
            // 
            this.discountDataGridViewTextBoxColumn.DataPropertyName = "Discount";
            this.discountDataGridViewTextBoxColumn.HeaderText = "Discount";
            this.discountDataGridViewTextBoxColumn.Name = "discountDataGridViewTextBoxColumn";
            // 
            // costOfSaleDataGridViewTextBoxColumn
            // 
            this.costOfSaleDataGridViewTextBoxColumn.DataPropertyName = "CostOfSale";
            this.costOfSaleDataGridViewTextBoxColumn.HeaderText = "CostOfSale";
            this.costOfSaleDataGridViewTextBoxColumn.Name = "costOfSaleDataGridViewTextBoxColumn";
            // 
            // btAddSale
            // 
            this.btAddSale.Location = new System.Drawing.Point(1151, 20);
            this.btAddSale.Name = "btAddSale";
            this.btAddSale.Size = new System.Drawing.Size(84, 24);
            this.btAddSale.TabIndex = 4;
            this.btAddSale.Text = "ADD SALE";
            this.btAddSale.UseVisualStyleBackColor = true;
            this.btAddSale.Click += new System.EventHandler(this.btAddSale_Click);
            // 
            // cbDiscount
            // 
            this.cbDiscount.BackColor = System.Drawing.Color.BurlyWood;
            this.cbDiscount.FormattingEnabled = true;
            this.cbDiscount.Items.AddRange(new object[] {
            "0%",
            "5%",
            "10%"});
            this.cbDiscount.Location = new System.Drawing.Point(944, 20);
            this.cbDiscount.Name = "cbDiscount";
            this.cbDiscount.Size = new System.Drawing.Size(121, 21);
            this.cbDiscount.TabIndex = 3;
            // 
            // cbPaymentType
            // 
            this.cbPaymentType.BackColor = System.Drawing.Color.BurlyWood;
            this.cbPaymentType.FormattingEnabled = true;
            this.cbPaymentType.Items.AddRange(new object[] {
            "CARD",
            "CASH"});
            this.cbPaymentType.Location = new System.Drawing.Point(668, 19);
            this.cbPaymentType.Name = "cbPaymentType";
            this.cbPaymentType.Size = new System.Drawing.Size(121, 21);
            this.cbPaymentType.TabIndex = 2;
            // 
            // tbEmpID
            // 
            this.tbEmpID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbEmpID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "EmployeeID", true));
            this.tbEmpID.Location = new System.Drawing.Point(403, 20);
            this.tbEmpID.Name = "tbEmpID";
            this.tbEmpID.Size = new System.Drawing.Size(106, 20);
            this.tbEmpID.TabIndex = 1;
            this.tbEmpID.TextChanged += new System.EventHandler(this.tbEmpID_TextChanged);
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.dsSales;
            // 
            // tbCustID
            // 
            this.tbCustID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbCustID.Location = new System.Drawing.Point(161, 20);
            this.tbCustID.Name = "tbCustID";
            this.tbCustID.Size = new System.Drawing.Size(106, 20);
            this.tbCustID.TabIndex = 0;
            this.tbCustID.TextChanged += new System.EventHandler(this.tbCustID_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnAddSaleItem);
            this.groupBox2.Controls.Add(this.tbQuant);
            this.groupBox2.Controls.Add(this.tbDescrip);
            this.groupBox2.Controls.Add(this.tbItemPrice);
            this.groupBox2.Controls.Add(this.tbInvID);
            this.groupBox2.Controls.Add(this.tbOrderID);
            this.groupBox2.Controls.Add(this.dataGridView3);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tbInvSearch);
            this.groupBox2.Controls.Add(this.dataGridView2);
            this.groupBox2.Location = new System.Drawing.Point(13, 294);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1276, 360);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ADD SALE ITEM";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1223, 313);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 36;
            this.pictureBox3.TabStop = false;
            this.toolTip3.SetToolTip(this.pictureBox3, "After Double Clicking On Item To Add, Enter The Current OrderID and Quantity To P" +
        "urchase, Then Add Sale Item");
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(684, 19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 35;
            this.pictureBox2.TabStop = false;
            this.toolTip2.SetToolTip(this.pictureBox2, "Search Through Inventory For Item To Add To The Current Sale, Double Click On The" +
        " Item Name Fill In TextBoxes Below");
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(869, 317);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "QUANTITY:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(655, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "DESCRIPTION:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(436, 317);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "ITEM PRICE:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(207, 314);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "INVENTORY ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 315);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "ORDER ID:";
            // 
            // btnAddSaleItem
            // 
            this.btnAddSaleItem.Location = new System.Drawing.Point(1114, 311);
            this.btnAddSaleItem.Name = "btnAddSaleItem";
            this.btnAddSaleItem.Size = new System.Drawing.Size(103, 24);
            this.btnAddSaleItem.TabIndex = 10;
            this.btnAddSaleItem.Text = "ADD SALE ITEM";
            this.btnAddSaleItem.UseVisualStyleBackColor = true;
            this.btnAddSaleItem.Click += new System.EventHandler(this.btnAddSaleItem_Click);
            // 
            // tbQuant
            // 
            this.tbQuant.BackColor = System.Drawing.Color.BurlyWood;
            this.tbQuant.Location = new System.Drawing.Point(940, 314);
            this.tbQuant.Name = "tbQuant";
            this.tbQuant.Size = new System.Drawing.Size(106, 20);
            this.tbQuant.TabIndex = 16;
            this.tbQuant.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbQuant_KeyPress_1);
            // 
            // tbDescrip
            // 
            this.tbDescrip.BackColor = System.Drawing.Color.BurlyWood;
            this.tbDescrip.Location = new System.Drawing.Point(744, 312);
            this.tbDescrip.Name = "tbDescrip";
            this.tbDescrip.ReadOnly = true;
            this.tbDescrip.Size = new System.Drawing.Size(106, 20);
            this.tbDescrip.TabIndex = 15;
            this.tbDescrip.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescrip_KeyPress);
            // 
            // tbItemPrice
            // 
            this.tbItemPrice.BackColor = System.Drawing.Color.BurlyWood;
            this.tbItemPrice.Location = new System.Drawing.Point(513, 312);
            this.tbItemPrice.Name = "tbItemPrice";
            this.tbItemPrice.ReadOnly = true;
            this.tbItemPrice.Size = new System.Drawing.Size(106, 20);
            this.tbItemPrice.TabIndex = 14;
            this.tbItemPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbItemPrice_KeyPress_1);
            // 
            // tbInvID
            // 
            this.tbInvID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbInvID.Location = new System.Drawing.Point(294, 311);
            this.tbInvID.Name = "tbInvID";
            this.tbInvID.ReadOnly = true;
            this.tbInvID.Size = new System.Drawing.Size(106, 20);
            this.tbInvID.TabIndex = 13;
            this.tbInvID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbInvID_KeyPress_1);
            // 
            // tbOrderID
            // 
            this.tbOrderID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOrderID.Location = new System.Drawing.Point(72, 311);
            this.tbOrderID.Name = "tbOrderID";
            this.tbOrderID.Size = new System.Drawing.Size(106, 20);
            this.tbOrderID.TabIndex = 12;
            this.tbOrderID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOrderID_KeyPress_1);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemIDDataGridViewTextBoxColumn,
            this.orderIDDataGridViewTextBoxColumn1,
            this.inventoryIDDataGridViewTextBoxColumn1,
            this.itemPriceDataGridViewTextBoxColumn,
            this.itemDescriptionDataGridViewTextBoxColumn,
            this.itemQuantityDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.itemListBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(7, 167);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1263, 120);
            this.dataGridView3.TabIndex = 11;
            // 
            // itemIDDataGridViewTextBoxColumn
            // 
            this.itemIDDataGridViewTextBoxColumn.DataPropertyName = "ItemID";
            this.itemIDDataGridViewTextBoxColumn.HeaderText = "ItemID";
            this.itemIDDataGridViewTextBoxColumn.Name = "itemIDDataGridViewTextBoxColumn";
            // 
            // orderIDDataGridViewTextBoxColumn1
            // 
            this.orderIDDataGridViewTextBoxColumn1.DataPropertyName = "OrderID";
            this.orderIDDataGridViewTextBoxColumn1.HeaderText = "OrderID";
            this.orderIDDataGridViewTextBoxColumn1.Name = "orderIDDataGridViewTextBoxColumn1";
            // 
            // inventoryIDDataGridViewTextBoxColumn1
            // 
            this.inventoryIDDataGridViewTextBoxColumn1.DataPropertyName = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn1.HeaderText = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn1.Name = "inventoryIDDataGridViewTextBoxColumn1";
            this.inventoryIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // itemPriceDataGridViewTextBoxColumn
            // 
            this.itemPriceDataGridViewTextBoxColumn.DataPropertyName = "itemPrice";
            this.itemPriceDataGridViewTextBoxColumn.HeaderText = "itemPrice";
            this.itemPriceDataGridViewTextBoxColumn.Name = "itemPriceDataGridViewTextBoxColumn";
            // 
            // itemDescriptionDataGridViewTextBoxColumn
            // 
            this.itemDescriptionDataGridViewTextBoxColumn.DataPropertyName = "itemDescription";
            this.itemDescriptionDataGridViewTextBoxColumn.HeaderText = "itemDescription";
            this.itemDescriptionDataGridViewTextBoxColumn.Name = "itemDescriptionDataGridViewTextBoxColumn";
            // 
            // itemQuantityDataGridViewTextBoxColumn
            // 
            this.itemQuantityDataGridViewTextBoxColumn.DataPropertyName = "itemQuantity";
            this.itemQuantityDataGridViewTextBoxColumn.HeaderText = "itemQuantity";
            this.itemQuantityDataGridViewTextBoxColumn.Name = "itemQuantityDataGridViewTextBoxColumn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(446, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "SEARCH INVENTORY:";
            // 
            // tbInvSearch
            // 
            this.tbInvSearch.BackColor = System.Drawing.Color.BurlyWood;
            this.tbInvSearch.Location = new System.Drawing.Point(572, 19);
            this.tbInvSearch.Name = "tbInvSearch";
            this.tbInvSearch.Size = new System.Drawing.Size(106, 20);
            this.tbInvSearch.TabIndex = 10;
            this.tbInvSearch.TextChanged += new System.EventHandler(this.tbInvSearch_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.inventoryIDDataGridViewTextBoxColumn,
            this.invNameDataGridViewTextBoxColumn,
            this.invSellingPriceDataGridViewTextBoxColumn,
            this.invQuantityAvailableDataGridViewTextBoxColumn,
            this.invDescriptionDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.inventoryBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(7, 45);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1263, 116);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentDoubleClick);
            // 
            // inventoryIDDataGridViewTextBoxColumn
            // 
            this.inventoryIDDataGridViewTextBoxColumn.DataPropertyName = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn.HeaderText = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn.Name = "inventoryIDDataGridViewTextBoxColumn";
            this.inventoryIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // invNameDataGridViewTextBoxColumn
            // 
            this.invNameDataGridViewTextBoxColumn.DataPropertyName = "invName";
            this.invNameDataGridViewTextBoxColumn.HeaderText = "invName";
            this.invNameDataGridViewTextBoxColumn.Name = "invNameDataGridViewTextBoxColumn";
            // 
            // invSellingPriceDataGridViewTextBoxColumn
            // 
            this.invSellingPriceDataGridViewTextBoxColumn.DataPropertyName = "invSellingPrice";
            this.invSellingPriceDataGridViewTextBoxColumn.HeaderText = "invSellingPrice";
            this.invSellingPriceDataGridViewTextBoxColumn.Name = "invSellingPriceDataGridViewTextBoxColumn";
            // 
            // invQuantityAvailableDataGridViewTextBoxColumn
            // 
            this.invQuantityAvailableDataGridViewTextBoxColumn.DataPropertyName = "invQuantityAvailable";
            this.invQuantityAvailableDataGridViewTextBoxColumn.HeaderText = "invQuantityAvailable";
            this.invQuantityAvailableDataGridViewTextBoxColumn.Name = "invQuantityAvailableDataGridViewTextBoxColumn";
            // 
            // invDescriptionDataGridViewTextBoxColumn
            // 
            this.invDescriptionDataGridViewTextBoxColumn.DataPropertyName = "invDescription";
            this.invDescriptionDataGridViewTextBoxColumn.HeaderText = "invDescription";
            this.invDescriptionDataGridViewTextBoxColumn.Name = "invDescriptionDataGridViewTextBoxColumn";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBox4);
            this.groupBox3.Controls.Add(this.btCompTrans);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.tbOrderIDComp);
            this.groupBox3.Location = new System.Drawing.Point(13, 660);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1276, 68);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "COMPLETE TRANSACTION";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(879, 26);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(32, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 37;
            this.pictureBox4.TabStop = false;
            this.toolTip4.SetToolTip(this.pictureBox4, "Enter The Current OrderID Once All Items Have Been Added Then Click To Complete T" +
        "he Current Transaction");
            // 
            // btCompTrans
            // 
            this.btCompTrans.Location = new System.Drawing.Point(720, 22);
            this.btCompTrans.Name = "btCompTrans";
            this.btCompTrans.Size = new System.Drawing.Size(153, 30);
            this.btCompTrans.TabIndex = 22;
            this.btCompTrans.Text = "COMPLETE TRANSACTION";
            this.btCompTrans.UseVisualStyleBackColor = true;
            this.btCompTrans.Click += new System.EventHandler(this.btCompTrans_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(463, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "ENTER ORDER ID:";
            // 
            // tbOrderIDComp
            // 
            this.tbOrderIDComp.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOrderIDComp.Location = new System.Drawing.Point(572, 28);
            this.tbOrderIDComp.Name = "tbOrderIDComp";
            this.tbOrderIDComp.Size = new System.Drawing.Size(106, 20);
            this.tbOrderIDComp.TabIndex = 22;
            this.tbOrderIDComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOrderIDComp_KeyPress_1);
            // 
            // taEmpLogin
            // 
            this.taEmpLogin.ClearBeforeFill = true;
            // 
            // employeeBindingSource1
            // 
            this.employeeBindingSource1.DataMember = "Employee";
            this.employeeBindingSource1.DataSource = this.dsSales;
            // 
            // PROCESSTRANSACTION
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1303, 733);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "PROCESSTRANSACTION";
            this.Text = "PROCESS TRANSACTION";
            this.Load += new System.EventHandler(this.PROCESSTRANSACTION_Load);
            ((System.ComponentModel.ISupportInitialize)(this.orderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSales)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private group12DataSet dsSales;
        private System.Windows.Forms.BindingSource orderBindingSource;
        private group12DataSetTableAdapters.OrderTableAdapter taSalesDb;
        private System.Windows.Forms.BindingSource itemListBindingSource;
        private group12DataSetTableAdapters.ItemListTableAdapter taSaleItemsDb;
        private group12DataSetTableAdapters.CustomerTableAdapter taCustID;
        private group12DataSetTableAdapters.OrderTableAdapter taAddSale;
        private group12DataSetTableAdapters.InventoryTableAdapter taFindInv;
        private group12DataSetTableAdapters.ItemListTableAdapter taAddSaleItem;
        private group12DataSetTableAdapters.OrderTableAdapter taUpdateTotalDue;
        private group12DataSetTableAdapters.OrderTableAdapter taUpdateCostOfSale;
        private System.Windows.Forms.BindingSource inventoryBindingSource;
        private group12DataSetTableAdapters.InventoryTableAdapter taSearchTPINV;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIDNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOfSaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn paymentTypeDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costOfSaleDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btAddSale;
        private System.Windows.Forms.ComboBox cbDiscount;
        private System.Windows.Forms.ComboBox cbPaymentType;
        private System.Windows.Forms.TextBox tbEmpID;
        private System.Windows.Forms.TextBox tbCustID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbInvSearch;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invSellingPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invQuantityAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAddSaleItem;
        private System.Windows.Forms.TextBox tbQuant;
        private System.Windows.Forms.TextBox tbDescrip;
        private System.Windows.Forms.TextBox tbItemPrice;
        private System.Windows.Forms.TextBox tbInvID;
        private System.Windows.Forms.TextBox tbOrderID;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btCompTrans;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbOrderIDComp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.ToolTip toolTip4;
        private group12DataSetTableAdapters.EmployeeTableAdapter taEmpLogin;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private System.Windows.Forms.BindingSource employeeBindingSource1;
    }
}