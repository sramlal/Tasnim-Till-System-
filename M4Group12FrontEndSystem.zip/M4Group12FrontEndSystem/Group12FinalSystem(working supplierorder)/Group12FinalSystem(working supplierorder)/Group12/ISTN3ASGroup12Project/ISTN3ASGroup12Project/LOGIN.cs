﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }

        private void tbUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btLogin_Click(object sender, EventArgs e)
        {
            taLogin.FillByTwo(ds1group12.Employee, tbUsername.Text, tbPassword.Text);
            if (ds1group12.Employee.Rows.Count > 0)
            {
                string name = ds1group12.Employee.Rows[0].ItemArray[1].ToString();
                MessageBox.Show("Welcome! " + name);
                Form frm = this.MdiParent;

                MenuStrip ms = (MenuStrip)frm.Controls["menuStrip1"];
                ToolStripMenuItem t1 = (ToolStripMenuItem)ms.Items["menuSupplier"];
                ToolStripMenuItem t2 = (ToolStripMenuItem)ms.Items["menuReports"];
                ToolStripMenuItem t3 = (ToolStripMenuItem)ms.Items["menuStaff"];
                ToolStripMenuItem t4 = (ToolStripMenuItem)ms.Items["menuSales"];
                ToolStripMenuItem t5 = (ToolStripMenuItem)ms.Items["menuCustomer"];
                ToolStripMenuItem t6 = (ToolStripMenuItem)ms.Items["menuInventory"];
                ToolStripMenuItem t7 = (ToolStripMenuItem)ms.Items["menuInvoices"];

                ToolStripMenuItem loginItem = (ToolStripMenuItem)ms.Items["menuLogin"];

                ToolStripMenuItem t8 = (ToolStripMenuItem)ms.Items["menuTBLoginStatus"];

                if(name == "Manager")
                {
                    loginItem.Enabled = false;
                    t1.Enabled = true;
                    t2.Enabled = true;
                    t3.Enabled = true;
                    t4.Enabled = true;
                    t5.Enabled = true;
                    t6.Enabled = true;
                    t7.Enabled = true;
                }
                else
                {
                    loginItem.Enabled = false;
                    t4.Enabled = true;
                    t5.Enabled = true;
                    t6.Enabled = true;
                }

                t8.Text = name + " logged in";

                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Login");
            }
        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {
           
        }

        private void LOGIN_Load(object sender, EventArgs e)
        {

        }
        private void tbUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUsername_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
