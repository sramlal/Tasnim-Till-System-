﻿namespace Staff
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelWages = new System.Windows.Forms.Label();
            this.labelHoursWorked = new System.Windows.Forms.Label();
            this.labelCellNum = new System.Windows.Forms.Label();
            this.labelIDNo = new System.Windows.Forms.Label();
            this.labelLName = new System.Windows.Forms.Label();
            this.labelStaffFName = new System.Windows.Forms.Label();
            this.tbStaffHoursWorked = new System.Windows.Forms.TextBox();
            this.tbStaffWages = new System.Windows.Forms.TextBox();
            this.tbStaffLastName = new System.Windows.Forms.TextBox();
            this.tbStaffCellNo = new System.Windows.Forms.TextBox();
            this.tbStaffFirstName = new System.Windows.Forms.TextBox();
            this.gbStaffdb = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empFirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empLastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empIDNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empCellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hoursWorkedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empWagesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.group12DataSet = new Staff.group12DataSet();
            this.tbStaffSearch = new System.Windows.Forms.TextBox();
            this.labelStaffSearch = new System.Windows.Forms.Label();
            this.btUpdateEmployee = new System.Windows.Forms.Button();
            this.tbUSHWorked = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbUSIDNo = new System.Windows.Forms.TextBox();
            this.tbUSWages = new System.Windows.Forms.TextBox();
            this.tbUSLName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbUSName = new System.Windows.Forms.TextBox();
            this.tbStaffID = new System.Windows.Forms.TextBox();
            this.gbStaffDBEdit = new System.Windows.Forms.GroupBox();
            this.btStaffAdd = new System.Windows.Forms.Button();
            this.gbUpdate = new System.Windows.Forms.GroupBox();
            this.tbCellNo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbUserID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.employeeTableAdapter = new Staff.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.gbStaffdb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).BeginInit();
            this.gbStaffDBEdit.SuspendLayout();
            this.gbUpdate.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelWages
            // 
            this.labelWages.AutoSize = true;
            this.labelWages.Location = new System.Drawing.Point(388, 72);
            this.labelWages.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWages.Name = "labelWages";
            this.labelWages.Size = new System.Drawing.Size(90, 13);
            this.labelWages.TabIndex = 17;
            this.labelWages.Text = "ENTER WAGES:";
            // 
            // labelHoursWorked
            // 
            this.labelHoursWorked.AutoSize = true;
            this.labelHoursWorked.Location = new System.Drawing.Point(337, 40);
            this.labelHoursWorked.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHoursWorked.Name = "labelHoursWorked";
            this.labelHoursWorked.Size = new System.Drawing.Size(141, 13);
            this.labelHoursWorked.TabIndex = 14;
            this.labelHoursWorked.Text = "ENTER HOURS WORKED:";
            // 
            // labelCellNum
            // 
            this.labelCellNum.AutoSize = true;
            this.labelCellNum.Location = new System.Drawing.Point(17, 144);
            this.labelCellNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCellNum.Name = "labelCellNum";
            this.labelCellNum.Size = new System.Drawing.Size(126, 13);
            this.labelCellNum.TabIndex = 15;
            this.labelCellNum.Text = "ENTER CELL NUMBER:";
            // 
            // labelIDNo
            // 
            this.labelIDNo.AutoSize = true;
            this.labelIDNo.Location = new System.Drawing.Point(17, 106);
            this.labelIDNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIDNo.Name = "labelIDNo";
            this.labelIDNo.Size = new System.Drawing.Size(111, 13);
            this.labelIDNo.TabIndex = 13;
            this.labelIDNo.Text = "ENTER ID NUMBER:";
            // 
            // labelLName
            // 
            this.labelLName.AutoSize = true;
            this.labelLName.Location = new System.Drawing.Point(17, 72);
            this.labelLName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLName.Name = "labelLName";
            this.labelLName.Size = new System.Drawing.Size(111, 13);
            this.labelLName.TabIndex = 12;
            this.labelLName.Text = "ENTER LAST NAME:";
            // 
            // labelStaffFName
            // 
            this.labelStaffFName.AutoSize = true;
            this.labelStaffFName.Location = new System.Drawing.Point(18, 37);
            this.labelStaffFName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelStaffFName.Name = "labelStaffFName";
            this.labelStaffFName.Size = new System.Drawing.Size(115, 13);
            this.labelStaffFName.TabIndex = 11;
            this.labelStaffFName.Text = "ENTER FIRST NAME:";
            // 
            // tbStaffHoursWorked
            // 
            this.tbStaffHoursWorked.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffHoursWorked.Location = new System.Drawing.Point(482, 37);
            this.tbStaffHoursWorked.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffHoursWorked.Name = "tbStaffHoursWorked";
            this.tbStaffHoursWorked.Size = new System.Drawing.Size(116, 20);
            this.tbStaffHoursWorked.TabIndex = 9;
            // 
            // tbStaffWages
            // 
            this.tbStaffWages.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffWages.Location = new System.Drawing.Point(482, 72);
            this.tbStaffWages.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffWages.Name = "tbStaffWages";
            this.tbStaffWages.Size = new System.Drawing.Size(116, 20);
            this.tbStaffWages.TabIndex = 8;
            // 
            // tbStaffLastName
            // 
            this.tbStaffLastName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffLastName.Location = new System.Drawing.Point(158, 72);
            this.tbStaffLastName.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffLastName.Name = "tbStaffLastName";
            this.tbStaffLastName.Size = new System.Drawing.Size(116, 20);
            this.tbStaffLastName.TabIndex = 6;
            // 
            // tbStaffCellNo
            // 
            this.tbStaffCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffCellNo.Location = new System.Drawing.Point(158, 141);
            this.tbStaffCellNo.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffCellNo.Name = "tbStaffCellNo";
            this.tbStaffCellNo.Size = new System.Drawing.Size(116, 20);
            this.tbStaffCellNo.TabIndex = 5;
            // 
            // tbStaffFirstName
            // 
            this.tbStaffFirstName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffFirstName.Location = new System.Drawing.Point(158, 34);
            this.tbStaffFirstName.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffFirstName.Name = "tbStaffFirstName";
            this.tbStaffFirstName.Size = new System.Drawing.Size(116, 20);
            this.tbStaffFirstName.TabIndex = 4;
            // 
            // gbStaffdb
            // 
            this.gbStaffdb.Controls.Add(this.dataGridView1);
            this.gbStaffdb.Controls.Add(this.tbStaffSearch);
            this.gbStaffdb.Controls.Add(this.labelStaffSearch);
            this.gbStaffdb.Location = new System.Drawing.Point(2, 1);
            this.gbStaffdb.Margin = new System.Windows.Forms.Padding(2);
            this.gbStaffdb.Name = "gbStaffdb";
            this.gbStaffdb.Padding = new System.Windows.Forms.Padding(2);
            this.gbStaffdb.Size = new System.Drawing.Size(1168, 301);
            this.gbStaffdb.TabIndex = 6;
            this.gbStaffdb.TabStop = false;
            this.gbStaffdb.Text = "STAFF DATABASE";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.empFirstNameDataGridViewTextBoxColumn,
            this.empLastNameDataGridViewTextBoxColumn,
            this.empIDNoDataGridViewTextBoxColumn,
            this.empCellNoDataGridViewTextBoxColumn,
            this.hoursWorkedDataGridViewTextBoxColumn,
            this.empWagesDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.employeeBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(26, 37);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1124, 249);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // empFirstNameDataGridViewTextBoxColumn
            // 
            this.empFirstNameDataGridViewTextBoxColumn.DataPropertyName = "empFirstName";
            this.empFirstNameDataGridViewTextBoxColumn.HeaderText = "empFirstName";
            this.empFirstNameDataGridViewTextBoxColumn.Name = "empFirstNameDataGridViewTextBoxColumn";
            // 
            // empLastNameDataGridViewTextBoxColumn
            // 
            this.empLastNameDataGridViewTextBoxColumn.DataPropertyName = "empLastName";
            this.empLastNameDataGridViewTextBoxColumn.HeaderText = "empLastName";
            this.empLastNameDataGridViewTextBoxColumn.Name = "empLastNameDataGridViewTextBoxColumn";
            // 
            // empIDNoDataGridViewTextBoxColumn
            // 
            this.empIDNoDataGridViewTextBoxColumn.DataPropertyName = "empIDNo";
            this.empIDNoDataGridViewTextBoxColumn.HeaderText = "empIDNo";
            this.empIDNoDataGridViewTextBoxColumn.Name = "empIDNoDataGridViewTextBoxColumn";
            // 
            // empCellNoDataGridViewTextBoxColumn
            // 
            this.empCellNoDataGridViewTextBoxColumn.DataPropertyName = "empCellNo";
            this.empCellNoDataGridViewTextBoxColumn.HeaderText = "empCellNo";
            this.empCellNoDataGridViewTextBoxColumn.Name = "empCellNoDataGridViewTextBoxColumn";
            // 
            // hoursWorkedDataGridViewTextBoxColumn
            // 
            this.hoursWorkedDataGridViewTextBoxColumn.DataPropertyName = "HoursWorked";
            this.hoursWorkedDataGridViewTextBoxColumn.HeaderText = "HoursWorked";
            this.hoursWorkedDataGridViewTextBoxColumn.Name = "hoursWorkedDataGridViewTextBoxColumn";
            // 
            // empWagesDataGridViewTextBoxColumn
            // 
            this.empWagesDataGridViewTextBoxColumn.DataPropertyName = "empWages";
            this.empWagesDataGridViewTextBoxColumn.HeaderText = "empWages";
            this.empWagesDataGridViewTextBoxColumn.Name = "empWagesDataGridViewTextBoxColumn";
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.group12DataSet;
            // 
            // group12DataSet
            // 
            this.group12DataSet.DataSetName = "group12DataSet";
            this.group12DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbStaffSearch
            // 
            this.tbStaffSearch.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffSearch.Location = new System.Drawing.Point(358, 12);
            this.tbStaffSearch.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffSearch.Name = "tbStaffSearch";
            this.tbStaffSearch.Size = new System.Drawing.Size(176, 20);
            this.tbStaffSearch.TabIndex = 3;
            this.tbStaffSearch.TextChanged += new System.EventHandler(this.tbStaffSearch_TextChanged);
            // 
            // labelStaffSearch
            // 
            this.labelStaffSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelStaffSearch.AutoSize = true;
            this.labelStaffSearch.Location = new System.Drawing.Point(171, 15);
            this.labelStaffSearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelStaffSearch.Name = "labelStaffSearch";
            this.labelStaffSearch.Size = new System.Drawing.Size(147, 13);
            this.labelStaffSearch.TabIndex = 2;
            this.labelStaffSearch.Text = "SEARCH STAFF SURNAME:";
            // 
            // btUpdateEmployee
            // 
            this.btUpdateEmployee.BackColor = System.Drawing.Color.BurlyWood;
            this.btUpdateEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btUpdateEmployee.Location = new System.Drawing.Point(482, 120);
            this.btUpdateEmployee.Margin = new System.Windows.Forms.Padding(2);
            this.btUpdateEmployee.Name = "btUpdateEmployee";
            this.btUpdateEmployee.Size = new System.Drawing.Size(125, 31);
            this.btUpdateEmployee.TabIndex = 32;
            this.btUpdateEmployee.Text = "UPDATE EMPLOYEE";
            this.btUpdateEmployee.UseVisualStyleBackColor = false;
            this.btUpdateEmployee.Click += new System.EventHandler(this.btUpdateEmployee_Click);
            // 
            // tbUSHWorked
            // 
            this.tbUSHWorked.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSHWorked.Location = new System.Drawing.Point(482, 40);
            this.tbUSHWorked.Margin = new System.Windows.Forms.Padding(2);
            this.tbUSHWorked.Name = "tbUSHWorked";
            this.tbUSHWorked.Size = new System.Drawing.Size(116, 20);
            this.tbUSHWorked.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 81);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "FIRST NAME:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 120);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 24;
            this.label2.Text = "LAST NAME:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 158);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "ID NUMBER:";
            // 
            // tbUSIDNo
            // 
            this.tbUSIDNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSIDNo.Location = new System.Drawing.Point(158, 151);
            this.tbUSIDNo.Margin = new System.Windows.Forms.Padding(2);
            this.tbUSIDNo.Name = "tbUSIDNo";
            this.tbUSIDNo.Size = new System.Drawing.Size(116, 20);
            this.tbUSIDNo.TabIndex = 29;
            // 
            // tbUSWages
            // 
            this.tbUSWages.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSWages.Location = new System.Drawing.Point(482, 81);
            this.tbUSWages.Margin = new System.Windows.Forms.Padding(2);
            this.tbUSWages.Name = "tbUSWages";
            this.tbUSWages.Size = new System.Drawing.Size(116, 20);
            this.tbUSWages.TabIndex = 31;
            // 
            // tbUSLName
            // 
            this.tbUSLName.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbUSLName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSLName.Location = new System.Drawing.Point(158, 113);
            this.tbUSLName.Margin = new System.Windows.Forms.Padding(2);
            this.tbUSLName.Name = "tbUSLName";
            this.tbUSLName.Size = new System.Drawing.Size(116, 20);
            this.tbUSLName.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(337, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 13);
            this.label4.TabIndex = 26;
            this.label4.Text = "ENTER HOURS WORKED:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(338, 81);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 13);
            this.label5.TabIndex = 27;
            this.label5.Text = "ENTER WAGES:";
            // 
            // tbUSName
            // 
            this.tbUSName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSName.Location = new System.Drawing.Point(158, 78);
            this.tbUSName.Margin = new System.Windows.Forms.Padding(2);
            this.tbUSName.Name = "tbUSName";
            this.tbUSName.Size = new System.Drawing.Size(116, 20);
            this.tbUSName.TabIndex = 23;
            // 
            // tbStaffID
            // 
            this.tbStaffID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffID.Location = new System.Drawing.Point(158, 106);
            this.tbStaffID.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffID.Name = "tbStaffID";
            this.tbStaffID.Size = new System.Drawing.Size(116, 20);
            this.tbStaffID.TabIndex = 10;
            // 
            // gbStaffDBEdit
            // 
            this.gbStaffDBEdit.Controls.Add(this.btStaffAdd);
            this.gbStaffDBEdit.Controls.Add(this.labelWages);
            this.gbStaffDBEdit.Controls.Add(this.labelCellNum);
            this.gbStaffDBEdit.Controls.Add(this.labelHoursWorked);
            this.gbStaffDBEdit.Controls.Add(this.labelIDNo);
            this.gbStaffDBEdit.Controls.Add(this.labelLName);
            this.gbStaffDBEdit.Controls.Add(this.labelStaffFName);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffID);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffHoursWorked);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffWages);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffLastName);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffCellNo);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffFirstName);
            this.gbStaffDBEdit.Location = new System.Drawing.Point(2, 306);
            this.gbStaffDBEdit.Margin = new System.Windows.Forms.Padding(2);
            this.gbStaffDBEdit.Name = "gbStaffDBEdit";
            this.gbStaffDBEdit.Padding = new System.Windows.Forms.Padding(2);
            this.gbStaffDBEdit.Size = new System.Drawing.Size(1168, 186);
            this.gbStaffDBEdit.TabIndex = 7;
            this.gbStaffDBEdit.TabStop = false;
            this.gbStaffDBEdit.Text = "ADD STAFF MEMBER";
            // 
            // btStaffAdd
            // 
            this.btStaffAdd.BackColor = System.Drawing.Color.BurlyWood;
            this.btStaffAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btStaffAdd.Location = new System.Drawing.Point(482, 106);
            this.btStaffAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btStaffAdd.Name = "btStaffAdd";
            this.btStaffAdd.Size = new System.Drawing.Size(116, 27);
            this.btStaffAdd.TabIndex = 19;
            this.btStaffAdd.Text = "ADD EMPLOYEE";
            this.btStaffAdd.UseVisualStyleBackColor = false;
            this.btStaffAdd.Click += new System.EventHandler(this.btStaffAdd_Click);
            // 
            // gbUpdate
            // 
            this.gbUpdate.Controls.Add(this.tbCellNo);
            this.gbUpdate.Controls.Add(this.label7);
            this.gbUpdate.Controls.Add(this.tbUserID);
            this.gbUpdate.Controls.Add(this.label6);
            this.gbUpdate.Controls.Add(this.btUpdateEmployee);
            this.gbUpdate.Controls.Add(this.tbUSHWorked);
            this.gbUpdate.Controls.Add(this.label1);
            this.gbUpdate.Controls.Add(this.tbUSName);
            this.gbUpdate.Controls.Add(this.label2);
            this.gbUpdate.Controls.Add(this.label5);
            this.gbUpdate.Controls.Add(this.label3);
            this.gbUpdate.Controls.Add(this.label4);
            this.gbUpdate.Controls.Add(this.tbUSIDNo);
            this.gbUpdate.Controls.Add(this.tbUSLName);
            this.gbUpdate.Controls.Add(this.tbUSWages);
            this.gbUpdate.Location = new System.Drawing.Point(2, 526);
            this.gbUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.gbUpdate.Name = "gbUpdate";
            this.gbUpdate.Padding = new System.Windows.Forms.Padding(2);
            this.gbUpdate.Size = new System.Drawing.Size(1168, 301);
            this.gbUpdate.TabIndex = 8;
            this.gbUpdate.TabStop = false;
            this.gbUpdate.Text = "UPDATE EMPLOYEE DETAILS";
            // 
            // tbCellNo
            // 
            this.tbCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbCellNo.Location = new System.Drawing.Point(158, 186);
            this.tbCellNo.Name = "tbCellNo";
            this.tbCellNo.Size = new System.Drawing.Size(116, 20);
            this.tbCellNo.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 13);
            this.label7.TabIndex = 35;
            this.label7.Text = "EMPLOYEE CELL NO.";
            // 
            // tbUserID
            // 
            this.tbUserID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUserID.Location = new System.Drawing.Point(158, 40);
            this.tbUserID.Name = "tbUserID";
            this.tbUserID.ReadOnly = true;
            this.tbUserID.Size = new System.Drawing.Size(116, 20);
            this.tbUserID.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 43);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 13);
            this.label6.TabIndex = 33;
            this.label6.Text = "EMPLOYEE ID:";
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Olive;
            this.ClientSize = new System.Drawing.Size(1254, 831);
            this.Controls.Add(this.gbStaffdb);
            this.Controls.Add(this.gbStaffDBEdit);
            this.Controls.Add(this.gbUpdate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbStaffdb.ResumeLayout(false);
            this.gbStaffdb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).EndInit();
            this.gbStaffDBEdit.ResumeLayout(false);
            this.gbStaffDBEdit.PerformLayout();
            this.gbUpdate.ResumeLayout(false);
            this.gbUpdate.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label labelWages;
        private System.Windows.Forms.Label labelHoursWorked;
        private System.Windows.Forms.Label labelCellNum;
        private System.Windows.Forms.Label labelIDNo;
        private System.Windows.Forms.Label labelLName;
        private System.Windows.Forms.Label labelStaffFName;
        private System.Windows.Forms.TextBox tbStaffHoursWorked;
        private System.Windows.Forms.TextBox tbStaffWages;
        private System.Windows.Forms.TextBox tbStaffLastName;
        private System.Windows.Forms.TextBox tbStaffCellNo;
        private System.Windows.Forms.TextBox tbStaffFirstName;
        private System.Windows.Forms.GroupBox gbStaffdb;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tbStaffSearch;
        private System.Windows.Forms.Label labelStaffSearch;
        private System.Windows.Forms.Button btUpdateEmployee;
        private System.Windows.Forms.TextBox tbUSHWorked;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbUSIDNo;
        private System.Windows.Forms.TextBox tbUSWages;
        private System.Windows.Forms.TextBox tbUSLName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbUSName;
        private System.Windows.Forms.TextBox tbStaffID;
        private System.Windows.Forms.GroupBox gbStaffDBEdit;
        private System.Windows.Forms.Button btStaffAdd;
        private System.Windows.Forms.GroupBox gbUpdate;
        private group12DataSet group12DataSet;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private group12DataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empFirstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empLastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empIDNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empCellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hoursWorkedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empWagesDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox tbUserID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbCellNo;
        private System.Windows.Forms.Label label7;
    }
}

