﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class PROCESSTRANSACTION : Form
    {
        public PROCESSTRANSACTION()
        {
            InitializeComponent();
        }

        private void PROCESSTRANSACTION_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.ItemList' table. You can move, or remove it, as needed.
            this.taSaleItemsDb.Fill(this.dsSales.ItemList);
            // TODO: This line of code loads data into the 'group12DataSet.Order' table. You can move, or remove it, as needed.
            this.taSalesDb.Fill(this.dsSales.Order);

            this.taFindInv.Fill(this.dsSales.Inventory);

            

        }

        private void dataGridView2_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView2.CurrentRow.Selected = true;
            tbInvID.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
            tbItemPrice.Text = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
            tbDescrip.Text = dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString();

        }

        private void tbInvSearch_TextChanged(object sender, EventArgs e)
        {
            taFindInv.Search(dsSales.Inventory, tbInvSearch.Text);
        }

        private void btAddSale_Click(object sender, EventArgs e)
        {
            int paymentType = 0;
            int CusId = int.Parse(tbCustID.Text);
            int EmpID = int.Parse(tbEmpID.Text);
            decimal TotalDue = 0;
            string vDiscount = "0";
            short vOut = Convert.ToInt16(vDiscount);
            decimal CostOfSale = 0;
            string Date = DateTime.Now.ToString();
            try
            {
                if (cbDiscount.SelectedItem.ToString() == "0%")
                {
                    vDiscount = "0";
                    vOut = Convert.ToInt16(vDiscount);
                }
                else if (cbDiscount.SelectedItem.ToString() == "5%")
                {
                    vDiscount = "5";
                    vOut = Convert.ToInt16(vDiscount);
                }

                else if (cbDiscount.SelectedItem.ToString() == "10%")
                {
                    vDiscount = "10";
                    vOut = Convert.ToInt16(vDiscount);
                }

                if ((cbPaymentType.Text).ToString() == "Card")
                {
                    paymentType = 1;
                }

                taAddSale.InsertQuery(CusId, EmpID, DateTime.Now.ToString(), TotalDue, paymentType, vOut, CostOfSale);
                MessageBox.Show("Your Order Has Been Added, Please Reload The Page");
            }
            catch
            {
                MessageBox.Show("ORDER COULD NOT BE ADDED, PLEASE TRY AGAIN. ENSURE ALL BOXES ARE FILLED OUT!");
            }
        }

        private void btnAddSaleItem_Click(object sender, EventArgs e)
        {
            try { 
            string quantStr = tbQuant.Text.ToString();
            short quant = Convert.ToInt16(quantStr);

            taAddSaleItem.AddItem(int.Parse(tbOrderID.Text), int.Parse(tbInvID.Text), decimal.Parse(tbItemPrice.Text), tbDescrip.Text.ToString(), quant);
                MessageBox.Show("Item Added Successfully, Please Reload Page To View Changes");
            }
            catch
            {
                MessageBox.Show("THERE WAS AN ERROR ADDING YOUR ITEM, PLEASE TRY AGAIN!");
            }
        }

        private void btCompTrans_Click(object sender, EventArgs e)
        {
            decimal totalNoDiscount = 0;
            decimal total = 0;

            for (int i = 0; i < dsSales.ItemList.Rows.Count; i++)
            {
                try
                {
                    decimal multip = 0;
                    decimal multip1 = 0;
                    string multip2Str = "0";
                    short multip2Short = Convert.ToInt16(multip2Str);
                    decimal multip2 = 0;
                    var ordID = dsSales.ItemList.Rows[i]["OrderID"];
                    if (ordID.ToString() == tbOrderIDComp.Text)
                    {
                        multip1 = ((decimal)dsSales.ItemList.Rows[i]["itemPrice"]);
                        multip2Str = (dsSales.ItemList.Rows[i]["itemQuantity"]).ToString();
                        multip2Short = Convert.ToInt16(multip2Str);
                        multip2 = int.Parse(multip2Short.ToString());
                        multip = multip1 * multip2;
                        totalNoDiscount += multip;
                    }


                    if (cbDiscount.Text == "5%")
                    {
                        total = totalNoDiscount - ((5 / 100) * totalNoDiscount);
                    }
                    else if (cbDiscount.Text == "10%")
                    {
                        total = totalNoDiscount - ((10 / 100) * totalNoDiscount);
                    }
                    else
                    {
                        total = totalNoDiscount;
                    }
                }

                catch
                {
                    MessageBox.Show("THERE WAS AN ERROR, PLEASE TRY AGAIN!");
                }
            }


            taUpdateTotalDue.UpdateTotalDue(total, int.Parse((tbOrderIDComp.Text).ToString()));
            decimal costNoInflation = (decimal.Parse(total.ToString("n2")) / decimal.Parse((1.15).ToString("n2")));
            taUpdateCostOfSale.UpdateCostOfSale(costNoInflation, int.Parse(tbOrderIDComp.Text));
            MessageBox.Show("The total amount without discount is: " + totalNoDiscount + "\n");
            MessageBox.Show("The total amount with discount is: " + total + "\n");
            MessageBox.Show("The cost price is: " + costNoInflation + "\n");
        }

        private void tbEmpID_TextChanged(object sender, EventArgs e)
        {

        }
        private void tbOrderIDComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOrderID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbInvID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbItemPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbQuant_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbQuant_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbCustID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbEmpID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbCustID_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbOrderID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbInvID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbItemPrice_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbDescrip_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbQuant_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOrderIDComp_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
        
    




































































































































       /* private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add sale item?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                taAddSaleItem.AddSaleItem(int.Parse(tbOrderID.Text), decimal.Parse(tbItemPrice.Text), tbDescription.Text, short.Parse(tbQuantity.Text), int.Parse(tbInvID.Text));


            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            /*DialogResult dr = MessageBox.Show("Do you want to add sale item?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {

                for (int i = 0; i < dsSales.Inventory.Rows.Count; i++)
                {
                    var invName = dsSales.Inventory.Rows[i]["invName"];
                    if (invName == tbInvName)
                    {
                        var invenID = dsSales.Inventory.Rows[i]["InventoryID"];
                        var itemP = dsSales.Inventory.Rows[i]["invSellingPrice"];
                        var itemDescrip = dsSales.Inventory.Rows[i]["invDescription"];
                        taAddSaleItem.AddSaleItem(int.Parse(tbOrderID.Text), decimal.Parse(itemP.ToString()), itemDescrip.ToString(), short.Parse(tbQuantity.Text), int.Parse(invenID.ToString()));
                        MessageBox.Show("sale item added. Refreash page to view changes.");
                    }
                    else
                    {
                        MessageBox.Show("Cannot find item with that name");
                    }

                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }

        }

        private void btAddSale_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add sale?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {


                DateTime now = DateTime.Now;
                bool paymentType = true;



                if (cbPaymentType.Text == "Card")
                {
                    paymentType = false;
                }

                for (int i = 0; i < dsSales.Customer.Rows.Count; i++)
                {

                    if (tbAddCustEmail.Text == (dsSales.Customer.Rows[i]["custEmail"]).ToString())
                    {
                        var custID = int.Parse(dsSales.Customer.Rows[i]["CustIDNo"].ToString());

                        taAddSale.AddSale(int.Parse(custID.ToString()), int.Parse(tbStaffID.Text), now.ToString(), 0, paymentType, short.Parse(cbDiscount.Text), 0);
                        MessageBox.Show("Sale added, reload page to view changes.");
                    }
                    else
                    {
                        MessageBox.Show("Could not find customer", "Error");
                    }
                }

            }
            else
            {
                MessageBox.Show("Action Cancelled");
            }
        }

        private void btEndTransaction_Click(object sender, EventArgs e)
        {
            decimal totalNoDiscount = 0;
            decimal total = 0;
            for (int i = 0; i < dsSales.ItemList.Rows.Count; i++)
            {
                decimal multip = 0;
                var ordID = dsSales.ItemList.Rows[i]["OrderID"];
                if (ordID.ToString() == (tbTransCompID.Text).ToString())
                {
                    var temp1 = dsSales.ItemList.Rows[i]["itemPrice"];
                    var temp2 = dsSales.ItemList.Rows[i]["itemQuantity"];
                    multip = (decimal.Parse(temp1.ToString()) * (decimal.Parse(temp2.ToString())));
                    totalNoDiscount += multip;
                }
            }
            if (cbDiscount.Text == "5%")
            {
                total = totalNoDiscount - ((5 / 100) * totalNoDiscount);
            }
            else if (cbDiscount.Text == "10%")
            {
                total = totalNoDiscount - ((10 / 100) * totalNoDiscount);
            }
            else
            {
                total = totalNoDiscount;
            }
            taUpdateTotalDue.UpdateTotal(total, int.Parse(tbTransCompID.Text));

            //cost of sale
            decimal costNoInflation = (decimal.Parse(total.ToString("n2")) / decimal.Parse((1.15).ToString("n2")));

            taUpdateCostOfSale.UpdateCostOfSale(costNoInflation, int.Parse(tbTransCompID.Text));
            MessageBox.Show("The total amount without discount is: " + totalNoDiscount + "\n");
            MessageBox.Show("The total amount with discount is: " + total + "\n");
            MessageBox.Show("The cost price is: " + decimal.Parse(costNoInflation.ToString("N2")) + "\n");





            decimal totalNoDiscount = 0;
            decimal total = 0;

            for (int i = 0; i < dsSales.ItemList.Rows.Count; i++)
            {
                decimal multip = 0;
                var ordID = dsSales.ItemList.Rows[i]["OrderID"];
                if (ordID.ToString() == tbOrderID.Text)
                {
                    multip = ((decimal)dsSales.ItemList.Rows[i]["itemPrice"]) * ((decimal)dsSales.ItemList.Rows[i]["itemQuantity"]);
                    totalNoDiscount += multip;
                }
            }
        
            if (cbDiscount.Text == "5%")
            {
                total = totalNoDiscount - ((5 / 100) * totalNoDiscount);
            }
           else if (cbDiscount.Text == "10%")
            {
                total = totalNoDiscount - ((10 / 100) * totalNoDiscount);
            }
            else
            {
                total = totalNoDiscount;
            }
            
            taUpdateTotalDue.UpdateTotal(total, int.Parse((tbOrderID.Text).ToString()));
            
          
           
            
            //cost of sale
            decimal costNoInflation = 0;
            for (int i = 0; i < dsSales.ItemList.Rows.Count; i++)
            {
                decimal multi = 0;
                var inventIDSearch = dsSales.ItemList.Rows[i]["InventoryID"];
                var inventQuant = dsSales.ItemList.Rows[i]["itemQuantity"];
                for (int j = 0; j < dsSales.Inventory.Rows.Count; j++)
                {
                    var inventIDFind = dsSales.Inventory.Rows[j]["InventoryID"];
                    if (inventIDSearch == inventIDFind)
                    {
                        multi = ((decimal)inventQuant) * ((decimal)dsSales.Inventory.Rows[j]["invCostPrice"]);
                        costNoInflation += multi;
                    }
                }
            }

            taUpdateCostOfSale.UpdateCostOfSale(costNoInflation, int.Parse(tbOrderID.Text));
            MessageBox.Show("The total amount without discount is: " + totalNoDiscount + "\n");
            MessageBox.Show("The total amount with discount is: " + total + "\n");
            MessageBox.Show("The cost price is: " + costNoInflation + "\n");
        }

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            taSearchTPINV.FillBySearchInv(dsSales.Inventory, tbSearchTPInv.Text);
        }
    }
} 

    //private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) */
