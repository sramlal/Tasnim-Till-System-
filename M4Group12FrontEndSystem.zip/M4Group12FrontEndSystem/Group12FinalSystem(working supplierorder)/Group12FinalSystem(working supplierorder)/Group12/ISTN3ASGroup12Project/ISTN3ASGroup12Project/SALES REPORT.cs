﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class SALES_REPORT : Form
    {
        public SALES_REPORT()
        {
            InitializeComponent();
        }

        private void SALES_REPORT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Order' table. You can move, or remove it, as needed.
            this.OrderTableAdapter.Fill(this.group12DataSet.Order);
            this.customerTableAdapter1.Fill(this.group12DataSet.Customer);
            salesReport1.SetDataSource(group12DataSet);

            this.salesCrystalReport.RefreshReport();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
