﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class STAFF : Form
    {
        public STAFF()
        {
            InitializeComponent();
            taEmployee.Fill(dsEmployee.Employee);
        }

        private void STAFF_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Employee' table. You can move, or remove it, as needed.
            this.taEmployee.Fill(this.group12DataSet.Employee);
            // TODO: This line of code loads data into the 'group12DataSet.Employee' table. You can move, or remove it, as needed.
            this.taEmployee.Fill(this.dsEmployee.Employee);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbStaffSearch_TextChanged(object sender, EventArgs e)
        {
            taStaffSearch.FillByStaffSearch(dsEmployee.Employee, tbStaffSearch.Text);
        }

        private void gbStaffDBEdit_Enter(object sender, EventArgs e)
        {

        }

        private void btStaffAdd_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add employee?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                if (tbStaffID.Text.Length == 13 && tbStaffCellNo.Text.Length == 10 && (tbEmpEmail.Text.Contains("@gmail.com") == true))
                {

                    try
                    {
                        taAddStaff.InsertQuery(tbStaffFirstName.Text, tbStaffLastName.Text, tbStaffID.Text,
                        tbStaffCellNo.Text, "", double.Parse(tbStaffHoursWorked.Text), decimal.Parse(tbStaffWages.Text), tbEmpEmail.Text);
                        MessageBox.Show("Employee added to database, reload page to view changes.");
                    }
                    catch
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
                else
                {
                    if (tbStaffID.Text.Length < 13 && tbStaffID.Text != "")
                    {
                        MessageBox.Show("Invalid ID number", "Error");
                    }
                    if (tbStaffCellNo.Text.Length < 10 && tbStaffCellNo.Text != "")
                    {
                        MessageBox.Show("Invalid Cell number", "Error");
                    }
                    if ((tbEmpEmail.Text.Contains("@gmail.com") == false) && tbEmpEmail.Text != "")
                    {
                        MessageBox.Show("invalid email", "Error");
                    }
                    if (tbStaffFirstName.Text == "" || tbStaffLastName.Text == "" || tbStaffID.Text == "" ||
                        tbStaffCellNo.Text == "" || tbStaffHoursWorked.Text == "" || tbStaffWages.Text == "" || tbEmpEmail.Text == "")
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }

                }

            }

            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbStaffFirstName.Text = ""; tbStaffLastName.Text = ""; tbStaffID.Text = ""; tbStaffPassword.Text = "";
            tbStaffCellNo.Text = ""; tbStaffHoursWorked.Text = ""; tbStaffWages.Text = ""; tbEmpEmail.Text = "";


        }

        private void labelStaffFName_Click(object sender, EventArgs e)
        {

        }

       /* private void btUpdateEmployee_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update employee?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try {
                    taUpdateEmployee.UpdateStaffHoursAndWages(double.Parse(tbUSHWorked.Text), decimal.Parse(tbUSWages.Text),
                    tbUSName.Text, tbUSLName.Text, tbUSIDNo.Text);
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
                }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbUSHWorked.Text = ""; tbUSWages.Text = "";
            tbUSName.Text = ""; tbUSLName.Text = ""; tbUSIDNo.Text = "";
        }

        private void btUpdateWages_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update all wages?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try {
                    taUpdateAllWages.UpdateAllWages(decimal.Parse(tbAllWagesUpdate.Text));
                    MessageBox.Show("Updated all wages, reload page to view changes.");
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textbox", "Error");
                }

                }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbAllWagesUpdate.Text = "";
        }

        private void btUpdateWorkHours_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update all work hours?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try {
                    taUpdateAllHoursWorked.UpdateAllHoursWorked(double.Parse(tbAllHoursUpdate.Text));
                    MessageBox.Show("Updated all wages, reload page to view changes.");
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textbox", "Error");
                }
                }

            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbAllHoursUpdate.Text = "";
        } */

        private void btUpdateEmployee_Click_1(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update employee?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                if (tbUSIDNo.Text.Length == 13 && tbCellNo.Text.Length == 10 && (tbUEmpEmail.Text.Contains("@gmail.com") == true))
                {

                    try
                    {
                        taUpdateEmployee.UpdateQuery1(tbUSName.Text, tbUSLName.Text,tbUSIDNo.Text, tbCellNo.Text, "",
                        double.Parse(tbUSHWorked.Text), decimal.Parse(tbUSWages.Text), tbUEmpEmail.Text,  int.Parse(tbUserID.Text), int.Parse(tbUserID.Text));
                        MessageBox.Show("Update completed successfully, reload to view changes");
                    }
                    catch
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
                else
                {
                    if (tbUSIDNo.Text.Length < 13 && tbUSIDNo.Text != "")
                    {
                        MessageBox.Show("Invalid ID number", "Error");
                    }
                    if (tbCellNo.Text.Length < 10 && tbCellNo.Text != "")
                    {
                        MessageBox.Show("Invalid Cell number", "Error");
                    }
                    if ((tbUEmpEmail.Text.Contains("@gmail.com") == false) && tbUEmpEmail.Text != "")
                    {
                        MessageBox.Show("invalid email", "Error");
                    }
                    if (tbUSName.Text == "" || tbUSLName.Text == "" || tbUSIDNo.Text == "" ||
                        tbCellNo.Text == "" || tbUSHWorked.Text == "" || tbUSWages.Text == "" || tbUEmpEmail.Text == "" || tbUserID.Text == "")
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }

                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbUSHWorked.Text = ""; tbUSWages.Text = ""; tbUEmpEmail.Text = "";
            tbUSName.Text = ""; tbUSLName.Text = ""; tbUSIDNo.Text = ""; tbUserID.Text = ""; tbCellNo.Text = "";
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.CurrentRow.Selected = true;
            tbUserID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            tbUSName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            tbUSLName.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            tbUSIDNo.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            tbCellNo.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            tbUSHWorked.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            tbUSWages.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
            tbUEmpEmail.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
        }
        private void tbStaffCellNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void tbStaffHoursWorked_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void tbStaffWages_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void tbStaffID_KeyPress(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void tbStaffFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStaffLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSLName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSIDNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSWages_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbUSWages_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbCellNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUserID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSHWorked_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStaffFirstName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStaffLastName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStaffID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStaffHoursWorked_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
        }

        private void tbStaffWages_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStaffCellNo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSName_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void tbUSLName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSIDNo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbCellNo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSHWorked_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUSWages_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUserID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
