﻿
namespace ISTN3ASGroup12Project
{
    partial class MENU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MENU));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSupplier = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSuppEditSupplierDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSuppEditOrderDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuReports = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRepSales = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRepExpenses = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRepStaff = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRepInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRepSupplier = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRepCustomer = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStaff = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStaffEditStaffDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSales = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSalesEditSalesDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCustomer = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCustEditCustomerDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.menuInvEditInventoryDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.menuInvoices = new System.Windows.Forms.ToolStripMenuItem();
            this.menuInvSupplyInvoice = new System.Windows.Forms.ToolStripMenuItem();
            this.menuLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.menuLogoutExit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuLOLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.menuTBLoginStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.BurlyWood;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuLogin,
            this.menuSupplier,
            this.menuReports,
            this.menuStaff,
            this.menuSales,
            this.menuCustomer,
            this.menuInventory,
            this.menuInvoices,
            this.menuLogout,
            this.toolStripMenuItem1,
            this.toolStripTextBox1,
            this.menuTBLoginStatus});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1006, 27);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuLogin
            // 
            this.menuLogin.Name = "menuLogin";
            this.menuLogin.Size = new System.Drawing.Size(54, 23);
            this.menuLogin.Text = "LOGIN";
            this.menuLogin.Click += new System.EventHandler(this.menuLogin_Click);
            // 
            // menuSupplier
            // 
            this.menuSupplier.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuSuppEditSupplierDatabase,
            this.menuSuppEditOrderDatabase});
            this.menuSupplier.Name = "menuSupplier";
            this.menuSupplier.Size = new System.Drawing.Size(75, 23);
            this.menuSupplier.Text = "SUPPLIERS";
            this.menuSupplier.ToolTipText = "Edit Supplier Database and Order Database";
            this.menuSupplier.Click += new System.EventHandler(this.menuSupplier_Click);
            // 
            // menuSuppEditSupplierDatabase
            // 
            this.menuSuppEditSupplierDatabase.Name = "menuSuppEditSupplierDatabase";
            this.menuSuppEditSupplierDatabase.Size = new System.Drawing.Size(208, 22);
            this.menuSuppEditSupplierDatabase.Text = "EDIT SUPPLIER DATABASE";
            this.menuSuppEditSupplierDatabase.Click += new System.EventHandler(this.menuSuppEditSupplierDatabase_Click);
            // 
            // menuSuppEditOrderDatabase
            // 
            this.menuSuppEditOrderDatabase.Name = "menuSuppEditOrderDatabase";
            this.menuSuppEditOrderDatabase.Size = new System.Drawing.Size(208, 22);
            this.menuSuppEditOrderDatabase.Text = "EDIT ORDER DATABASE";
            this.menuSuppEditOrderDatabase.Click += new System.EventHandler(this.menuSuppEditOrderDatabase_Click);
            // 
            // menuReports
            // 
            this.menuReports.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuRepSales,
            this.menuRepExpenses,
            this.menuRepStaff,
            this.menuRepInventory,
            this.menuRepSupplier,
            this.menuRepCustomer});
            this.menuReports.Name = "menuReports";
            this.menuReports.Size = new System.Drawing.Size(66, 23);
            this.menuReports.Text = "REPORTS";
            this.menuReports.Click += new System.EventHandler(this.menuReports_Click);
            // 
            // menuRepSales
            // 
            this.menuRepSales.Name = "menuRepSales";
            this.menuRepSales.Size = new System.Drawing.Size(136, 22);
            this.menuRepSales.Text = "SALES";
            this.menuRepSales.Click += new System.EventHandler(this.menuRepSales_Click);
            // 
            // menuRepExpenses
            // 
            this.menuRepExpenses.Name = "menuRepExpenses";
            this.menuRepExpenses.Size = new System.Drawing.Size(136, 22);
            this.menuRepExpenses.Text = "EXPENSES";
            this.menuRepExpenses.Click += new System.EventHandler(this.menuRepExpenses_Click);
            // 
            // menuRepStaff
            // 
            this.menuRepStaff.Name = "menuRepStaff";
            this.menuRepStaff.Size = new System.Drawing.Size(136, 22);
            this.menuRepStaff.Text = "STAFF";
            this.menuRepStaff.Click += new System.EventHandler(this.menuRepStaff_Click);
            // 
            // menuRepInventory
            // 
            this.menuRepInventory.Name = "menuRepInventory";
            this.menuRepInventory.Size = new System.Drawing.Size(136, 22);
            this.menuRepInventory.Text = "INVENTORY";
            this.menuRepInventory.Click += new System.EventHandler(this.menuRepInventory_Click);
            // 
            // menuRepSupplier
            // 
            this.menuRepSupplier.Name = "menuRepSupplier";
            this.menuRepSupplier.Size = new System.Drawing.Size(136, 22);
            this.menuRepSupplier.Text = "SUPPLIER";
            this.menuRepSupplier.Click += new System.EventHandler(this.menuRepSupplier_Click);
            // 
            // menuRepCustomer
            // 
            this.menuRepCustomer.Name = "menuRepCustomer";
            this.menuRepCustomer.Size = new System.Drawing.Size(136, 22);
            this.menuRepCustomer.Text = "CUSTOMER";
            this.menuRepCustomer.Click += new System.EventHandler(this.menuRepCustomer_Click);
            // 
            // menuStaff
            // 
            this.menuStaff.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuStaffEditStaffDatabase});
            this.menuStaff.Name = "menuStaff";
            this.menuStaff.Size = new System.Drawing.Size(50, 23);
            this.menuStaff.Text = "STAFF";
            this.menuStaff.Click += new System.EventHandler(this.menuStaff_Click);
            // 
            // menuStaffEditStaffDatabase
            // 
            this.menuStaffEditStaffDatabase.Name = "menuStaffEditStaffDatabase";
            this.menuStaffEditStaffDatabase.Size = new System.Drawing.Size(189, 22);
            this.menuStaffEditStaffDatabase.Text = "EDIT STAFF DATABASE";
            this.menuStaffEditStaffDatabase.Click += new System.EventHandler(this.menuStaffEditStaffDatabase_Click);
            // 
            // menuSales
            // 
            this.menuSales.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuSalesEditSalesDatabase});
            this.menuSales.Name = "menuSales";
            this.menuSales.Size = new System.Drawing.Size(51, 23);
            this.menuSales.Text = "SALES";
            this.menuSales.Click += new System.EventHandler(this.menuSales_Click);
            // 
            // menuSalesEditSalesDatabase
            // 
            this.menuSalesEditSalesDatabase.Name = "menuSalesEditSalesDatabase";
            this.menuSalesEditSalesDatabase.Size = new System.Drawing.Size(190, 22);
            this.menuSalesEditSalesDatabase.Text = "EDIT SALES DATABASE";
            this.menuSalesEditSalesDatabase.Click += new System.EventHandler(this.menuSalesEditSalesDatabase_Click);
            // 
            // menuCustomer
            // 
            this.menuCustomer.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuCustEditCustomerDatabase});
            this.menuCustomer.Name = "menuCustomer";
            this.menuCustomer.Size = new System.Drawing.Size(79, 23);
            this.menuCustomer.Text = "CUSTOMER";
            this.menuCustomer.Click += new System.EventHandler(this.menuCustomer_Click);
            // 
            // menuCustEditCustomerDatabase
            // 
            this.menuCustEditCustomerDatabase.Name = "menuCustEditCustomerDatabase";
            this.menuCustEditCustomerDatabase.Size = new System.Drawing.Size(218, 22);
            this.menuCustEditCustomerDatabase.Text = "EDIT CUSTOMER DATABASE";
            this.menuCustEditCustomerDatabase.Click += new System.EventHandler(this.menuCustEditCustomerDatabase_Click);
            // 
            // menuInventory
            // 
            this.menuInventory.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuInvEditInventoryDatabase});
            this.menuInventory.Name = "menuInventory";
            this.menuInventory.Size = new System.Drawing.Size(81, 23);
            this.menuInventory.Text = "INVENTORY";
            this.menuInventory.Click += new System.EventHandler(this.menuInventory_Click);
            // 
            // menuInvEditInventoryDatabase
            // 
            this.menuInvEditInventoryDatabase.Name = "menuInvEditInventoryDatabase";
            this.menuInvEditInventoryDatabase.Size = new System.Drawing.Size(220, 22);
            this.menuInvEditInventoryDatabase.Text = "EDIT INVENTORY DATABASE";
            this.menuInvEditInventoryDatabase.Click += new System.EventHandler(this.menuInvEditInventoryDatabase_Click);
            // 
            // menuInvoices
            // 
            this.menuInvoices.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuInvSupplyInvoice});
            this.menuInvoices.Name = "menuInvoices";
            this.menuInvoices.Size = new System.Drawing.Size(70, 23);
            this.menuInvoices.Text = "INVOICES";
            this.menuInvoices.Click += new System.EventHandler(this.menuInvoices_Click);
            // 
            // menuInvSupplyInvoice
            // 
            this.menuInvSupplyInvoice.Name = "menuInvSupplyInvoice";
            this.menuInvSupplyInvoice.Size = new System.Drawing.Size(162, 22);
            this.menuInvSupplyInvoice.Text = "SUPPLY INVOICE";
            this.menuInvSupplyInvoice.Click += new System.EventHandler(this.menuInvSupplyInvoice_Click);
            // 
            // menuLogout
            // 
            this.menuLogout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuLogoutExit,
            this.menuLOLogout});
            this.menuLogout.Name = "menuLogout";
            this.menuLogout.Size = new System.Drawing.Size(65, 23);
            this.menuLogout.Text = "LOGOUT";
            this.menuLogout.Click += new System.EventHandler(this.menuLogout_Click);
            // 
            // menuLogoutExit
            // 
            this.menuLogoutExit.Name = "menuLogoutExit";
            this.menuLogoutExit.Size = new System.Drawing.Size(180, 22);
            this.menuLogoutExit.Text = "EXIT";
            this.menuLogoutExit.Click += new System.EventHandler(this.menuLogoutExit_Click);
            // 
            // menuLOLogout
            // 
            this.menuLOLogout.Name = "menuLOLogout";
            this.menuLOLogout.Size = new System.Drawing.Size(180, 22);
            this.menuLOLogout.Text = "LOGOUT";
            this.menuLOLogout.Click += new System.EventHandler(this.menuLOLogout_Click);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BackColor = System.Drawing.Color.BurlyWood;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(76, 23);
            // 
            // menuTBLoginStatus
            // 
            this.menuTBLoginStatus.Name = "menuTBLoginStatus";
            this.menuTBLoginStatus.Size = new System.Drawing.Size(77, 23);
            this.menuTBLoginStatus.Text = "logged out";
            this.menuTBLoginStatus.Click += new System.EventHandler(this.menuTBLoginStatus_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(47, 23);
            this.toolStripMenuItem1.Text = "HELP";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // MENU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 452);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MENU";
            this.Text = "MENU";
            this.Load += new System.EventHandler(this.MENU_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuLogin;
        private System.Windows.Forms.ToolStripMenuItem menuSupplier;
        private System.Windows.Forms.ToolStripMenuItem menuSuppEditSupplierDatabase;
        private System.Windows.Forms.ToolStripMenuItem menuSuppEditOrderDatabase;
        private System.Windows.Forms.ToolStripMenuItem menuReports;
        private System.Windows.Forms.ToolStripMenuItem menuRepSales;
        private System.Windows.Forms.ToolStripMenuItem menuRepExpenses;
        private System.Windows.Forms.ToolStripMenuItem menuRepStaff;
        private System.Windows.Forms.ToolStripMenuItem menuRepInventory;
        private System.Windows.Forms.ToolStripMenuItem menuRepSupplier;
        private System.Windows.Forms.ToolStripMenuItem menuRepCustomer;
        private System.Windows.Forms.ToolStripMenuItem menuStaff;
        private System.Windows.Forms.ToolStripMenuItem menuStaffEditStaffDatabase;
        private System.Windows.Forms.ToolStripMenuItem menuSales;
        private System.Windows.Forms.ToolStripMenuItem menuSalesEditSalesDatabase;
        private System.Windows.Forms.ToolStripMenuItem menuCustomer;
        private System.Windows.Forms.ToolStripMenuItem menuCustEditCustomerDatabase;
        private System.Windows.Forms.ToolStripMenuItem menuInventory;
        private System.Windows.Forms.ToolStripMenuItem menuInvEditInventoryDatabase;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripMenuItem menuTBLoginStatus;
        private System.Windows.Forms.ToolStripMenuItem menuInvoices;
        private System.Windows.Forms.ToolStripMenuItem menuInvSupplyInvoice;
        private System.Windows.Forms.ToolStripMenuItem menuLogout;
        private System.Windows.Forms.ToolStripMenuItem menuLogoutExit;
        private System.Windows.Forms.ToolStripMenuItem menuLOLogout;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
    }
}

