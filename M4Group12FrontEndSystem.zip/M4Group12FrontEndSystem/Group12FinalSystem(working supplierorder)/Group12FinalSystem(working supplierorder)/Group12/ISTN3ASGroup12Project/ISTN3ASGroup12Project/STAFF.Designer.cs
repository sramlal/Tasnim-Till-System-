﻿
namespace ISTN3ASGroup12Project
{
    partial class STAFF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(STAFF));
            this.gbStaffdb = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empFirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empLastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empIDNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empCellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hoursWorkedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empWagesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empEmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.group12DataSet = new ISTN3ASGroup12Project.group12DataSet();
            this.tbStaffSearch = new System.Windows.Forms.TextBox();
            this.labelStaffSearch = new System.Windows.Forms.Label();
            this.gbStaffDBEdit = new System.Windows.Forms.GroupBox();
            this.tbEmpEmail = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btStaffAdd = new System.Windows.Forms.Button();
            this.labelWages = new System.Windows.Forms.Label();
            this.labelSPassword = new System.Windows.Forms.Label();
            this.labelCellNum = new System.Windows.Forms.Label();
            this.labelHoursWorked = new System.Windows.Forms.Label();
            this.labelIDNo = new System.Windows.Forms.Label();
            this.labelLName = new System.Windows.Forms.Label();
            this.labelStaffFName = new System.Windows.Forms.Label();
            this.tbStaffID = new System.Windows.Forms.TextBox();
            this.tbStaffHoursWorked = new System.Windows.Forms.TextBox();
            this.tbStaffWages = new System.Windows.Forms.TextBox();
            this.tbStaffPassword = new System.Windows.Forms.TextBox();
            this.tbStaffLastName = new System.Windows.Forms.TextBox();
            this.tbStaffCellNo = new System.Windows.Forms.TextBox();
            this.tbStaffFirstName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.employeeBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.label9 = new System.Windows.Forms.Label();
            this.tbUEmpEmail = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btUpdateEmployee = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbUSWages = new System.Windows.Forms.TextBox();
            this.tbUSHWorked = new System.Windows.Forms.TextBox();
            this.tbCellNo = new System.Windows.Forms.TextBox();
            this.tbUSIDNo = new System.Windows.Forms.TextBox();
            this.tbUSLName = new System.Windows.Forms.TextBox();
            this.tbUSName = new System.Windows.Forms.TextBox();
            this.tbUserID = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsEmployee = new ISTN3ASGroup12Project.group12DataSet();
            this.taEmployee = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.taStaffSearch = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.taAddStaff = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.taUpdateEmployee = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.taUpdateAllHoursWorked = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.taUpdateAllWages = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.gbStaffdb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).BeginInit();
            this.gbStaffDBEdit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).BeginInit();
            this.SuspendLayout();
            // 
            // gbStaffdb
            // 
            this.gbStaffdb.Controls.Add(this.pictureBox1);
            this.gbStaffdb.Controls.Add(this.dataGridView1);
            this.gbStaffdb.Controls.Add(this.tbStaffSearch);
            this.gbStaffdb.Controls.Add(this.labelStaffSearch);
            this.gbStaffdb.Location = new System.Drawing.Point(59, 10);
            this.gbStaffdb.Margin = new System.Windows.Forms.Padding(2);
            this.gbStaffdb.Name = "gbStaffdb";
            this.gbStaffdb.Padding = new System.Windows.Forms.Padding(2);
            this.gbStaffdb.Size = new System.Drawing.Size(1168, 301);
            this.gbStaffdb.TabIndex = 0;
            this.gbStaffdb.TabStop = false;
            this.gbStaffdb.Text = "EMPLOYEE DATABASE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(539, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 33;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Search For An Employee In The Database");
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.employeeIDDataGridViewTextBoxColumn,
            this.empFirstNameDataGridViewTextBoxColumn,
            this.empLastNameDataGridViewTextBoxColumn,
            this.empIDNoDataGridViewTextBoxColumn,
            this.empCellNoDataGridViewTextBoxColumn,
            this.hoursWorkedDataGridViewTextBoxColumn,
            this.empWagesDataGridViewTextBoxColumn,
            this.empEmail});
            this.dataGridView1.DataSource = this.employeeBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(26, 37);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1124, 249);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeeIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // empFirstNameDataGridViewTextBoxColumn
            // 
            this.empFirstNameDataGridViewTextBoxColumn.DataPropertyName = "empFirstName";
            this.empFirstNameDataGridViewTextBoxColumn.HeaderText = "empFirstName";
            this.empFirstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empFirstNameDataGridViewTextBoxColumn.Name = "empFirstNameDataGridViewTextBoxColumn";
            this.empFirstNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.empFirstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // empLastNameDataGridViewTextBoxColumn
            // 
            this.empLastNameDataGridViewTextBoxColumn.DataPropertyName = "empLastName";
            this.empLastNameDataGridViewTextBoxColumn.HeaderText = "empLastName";
            this.empLastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empLastNameDataGridViewTextBoxColumn.Name = "empLastNameDataGridViewTextBoxColumn";
            this.empLastNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.empLastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // empIDNoDataGridViewTextBoxColumn
            // 
            this.empIDNoDataGridViewTextBoxColumn.DataPropertyName = "empIDNo";
            this.empIDNoDataGridViewTextBoxColumn.HeaderText = "empIDNo";
            this.empIDNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empIDNoDataGridViewTextBoxColumn.Name = "empIDNoDataGridViewTextBoxColumn";
            this.empIDNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.empIDNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // empCellNoDataGridViewTextBoxColumn
            // 
            this.empCellNoDataGridViewTextBoxColumn.DataPropertyName = "empCellNo";
            this.empCellNoDataGridViewTextBoxColumn.HeaderText = "empCellNo";
            this.empCellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empCellNoDataGridViewTextBoxColumn.Name = "empCellNoDataGridViewTextBoxColumn";
            this.empCellNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.empCellNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // hoursWorkedDataGridViewTextBoxColumn
            // 
            this.hoursWorkedDataGridViewTextBoxColumn.DataPropertyName = "HoursWorked";
            this.hoursWorkedDataGridViewTextBoxColumn.HeaderText = "HoursWorked";
            this.hoursWorkedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.hoursWorkedDataGridViewTextBoxColumn.Name = "hoursWorkedDataGridViewTextBoxColumn";
            this.hoursWorkedDataGridViewTextBoxColumn.ReadOnly = true;
            this.hoursWorkedDataGridViewTextBoxColumn.Width = 125;
            // 
            // empWagesDataGridViewTextBoxColumn
            // 
            this.empWagesDataGridViewTextBoxColumn.DataPropertyName = "empWages";
            this.empWagesDataGridViewTextBoxColumn.HeaderText = "empWages";
            this.empWagesDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.empWagesDataGridViewTextBoxColumn.Name = "empWagesDataGridViewTextBoxColumn";
            this.empWagesDataGridViewTextBoxColumn.ReadOnly = true;
            this.empWagesDataGridViewTextBoxColumn.Width = 125;
            // 
            // empEmail
            // 
            this.empEmail.DataPropertyName = "empEmail";
            this.empEmail.HeaderText = "empEmail";
            this.empEmail.Name = "empEmail";
            this.empEmail.ReadOnly = true;
            // 
            // employeeBindingSource1
            // 
            this.employeeBindingSource1.DataMember = "Employee";
            this.employeeBindingSource1.DataSource = this.group12DataSet;
            // 
            // group12DataSet
            // 
            this.group12DataSet.DataSetName = "group12DataSet";
            this.group12DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbStaffSearch
            // 
            this.tbStaffSearch.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffSearch.Location = new System.Drawing.Point(358, 12);
            this.tbStaffSearch.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffSearch.Name = "tbStaffSearch";
            this.tbStaffSearch.Size = new System.Drawing.Size(176, 20);
            this.tbStaffSearch.TabIndex = 3;
            this.tbStaffSearch.TextChanged += new System.EventHandler(this.tbStaffSearch_TextChanged);
            // 
            // labelStaffSearch
            // 
            this.labelStaffSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.labelStaffSearch.AutoSize = true;
            this.labelStaffSearch.Location = new System.Drawing.Point(171, 15);
            this.labelStaffSearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelStaffSearch.Name = "labelStaffSearch";
            this.labelStaffSearch.Size = new System.Drawing.Size(172, 13);
            this.labelStaffSearch.TabIndex = 2;
            this.labelStaffSearch.Text = "SEARCH EMPLOYEE SURNAME:";
            // 
            // gbStaffDBEdit
            // 
            this.gbStaffDBEdit.Controls.Add(this.tbEmpEmail);
            this.gbStaffDBEdit.Controls.Add(this.label8);
            this.gbStaffDBEdit.Controls.Add(this.pictureBox2);
            this.gbStaffDBEdit.Controls.Add(this.btStaffAdd);
            this.gbStaffDBEdit.Controls.Add(this.labelWages);
            this.gbStaffDBEdit.Controls.Add(this.labelSPassword);
            this.gbStaffDBEdit.Controls.Add(this.labelCellNum);
            this.gbStaffDBEdit.Controls.Add(this.labelHoursWorked);
            this.gbStaffDBEdit.Controls.Add(this.labelIDNo);
            this.gbStaffDBEdit.Controls.Add(this.labelLName);
            this.gbStaffDBEdit.Controls.Add(this.labelStaffFName);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffID);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffHoursWorked);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffWages);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffPassword);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffLastName);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffCellNo);
            this.gbStaffDBEdit.Controls.Add(this.tbStaffFirstName);
            this.gbStaffDBEdit.Location = new System.Drawing.Point(59, 332);
            this.gbStaffDBEdit.Margin = new System.Windows.Forms.Padding(2);
            this.gbStaffDBEdit.Name = "gbStaffDBEdit";
            this.gbStaffDBEdit.Padding = new System.Windows.Forms.Padding(2);
            this.gbStaffDBEdit.Size = new System.Drawing.Size(1168, 186);
            this.gbStaffDBEdit.TabIndex = 1;
            this.gbStaffDBEdit.TabStop = false;
            this.gbStaffDBEdit.Text = "EDIT EMPLOYEE DATABASE";
            this.gbStaffDBEdit.Enter += new System.EventHandler(this.gbStaffDBEdit_Enter);
            // 
            // tbEmpEmail
            // 
            this.tbEmpEmail.BackColor = System.Drawing.Color.BurlyWood;
            this.tbEmpEmail.Location = new System.Drawing.Point(795, 72);
            this.tbEmpEmail.Margin = new System.Windows.Forms.Padding(2);
            this.tbEmpEmail.Name = "tbEmpEmail";
            this.tbEmpEmail.Size = new System.Drawing.Size(116, 20);
            this.tbEmpEmail.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(709, 75);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "ENTER EMAIL:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1091, 81);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            this.toolTip2.SetToolTip(this.pictureBox2, "Add An Employee To The Database");
            // 
            // btStaffAdd
            // 
            this.btStaffAdd.BackColor = System.Drawing.Color.BurlyWood;
            this.btStaffAdd.Location = new System.Drawing.Point(971, 81);
            this.btStaffAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btStaffAdd.Name = "btStaffAdd";
            this.btStaffAdd.Size = new System.Drawing.Size(115, 20);
            this.btStaffAdd.TabIndex = 19;
            this.btStaffAdd.Text = "ADD EMPLOYEE";
            this.btStaffAdd.UseVisualStyleBackColor = false;
            this.btStaffAdd.Click += new System.EventHandler(this.btStaffAdd_Click);
            // 
            // labelWages
            // 
            this.labelWages.AutoSize = true;
            this.labelWages.Location = new System.Drawing.Point(387, 106);
            this.labelWages.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelWages.Name = "labelWages";
            this.labelWages.Size = new System.Drawing.Size(90, 13);
            this.labelWages.TabIndex = 17;
            this.labelWages.Text = "ENTER WAGES:";
            // 
            // labelSPassword
            // 
            this.labelSPassword.AutoSize = true;
            this.labelSPassword.Location = new System.Drawing.Point(367, 40);
            this.labelSPassword.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSPassword.Name = "labelSPassword";
            this.labelSPassword.Size = new System.Drawing.Size(113, 13);
            this.labelSPassword.TabIndex = 16;
            this.labelSPassword.Text = "ENTER PASSWORD:";
            // 
            // labelCellNum
            // 
            this.labelCellNum.AutoSize = true;
            this.labelCellNum.Location = new System.Drawing.Point(665, 44);
            this.labelCellNum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCellNum.Name = "labelCellNum";
            this.labelCellNum.Size = new System.Drawing.Size(126, 13);
            this.labelCellNum.TabIndex = 15;
            this.labelCellNum.Text = "ENTER CELL NUMBER:";
            // 
            // labelHoursWorked
            // 
            this.labelHoursWorked.AutoSize = true;
            this.labelHoursWorked.Location = new System.Drawing.Point(336, 72);
            this.labelHoursWorked.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHoursWorked.Name = "labelHoursWorked";
            this.labelHoursWorked.Size = new System.Drawing.Size(141, 13);
            this.labelHoursWorked.TabIndex = 14;
            this.labelHoursWorked.Text = "ENTER HOURS WORKED:";
            // 
            // labelIDNo
            // 
            this.labelIDNo.AutoSize = true;
            this.labelIDNo.Location = new System.Drawing.Point(64, 106);
            this.labelIDNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelIDNo.Name = "labelIDNo";
            this.labelIDNo.Size = new System.Drawing.Size(111, 13);
            this.labelIDNo.TabIndex = 13;
            this.labelIDNo.Text = "ENTER ID NUMBER:";
            // 
            // labelLName
            // 
            this.labelLName.AutoSize = true;
            this.labelLName.Location = new System.Drawing.Point(63, 72);
            this.labelLName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLName.Name = "labelLName";
            this.labelLName.Size = new System.Drawing.Size(111, 13);
            this.labelLName.TabIndex = 12;
            this.labelLName.Text = "ENTER LAST NAME:";
            // 
            // labelStaffFName
            // 
            this.labelStaffFName.AutoSize = true;
            this.labelStaffFName.Location = new System.Drawing.Point(60, 40);
            this.labelStaffFName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelStaffFName.Name = "labelStaffFName";
            this.labelStaffFName.Size = new System.Drawing.Size(115, 13);
            this.labelStaffFName.TabIndex = 11;
            this.labelStaffFName.Text = "ENTER FIRST NAME:";
            this.labelStaffFName.Click += new System.EventHandler(this.labelStaffFName_Click);
            // 
            // tbStaffID
            // 
            this.tbStaffID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffID.Location = new System.Drawing.Point(194, 106);
            this.tbStaffID.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffID.MaxLength = 13;
            this.tbStaffID.Name = "tbStaffID";
            this.tbStaffID.Size = new System.Drawing.Size(116, 20);
            this.tbStaffID.TabIndex = 10;
            this.tbStaffID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStaffID_KeyPress_1);
            // 
            // tbStaffHoursWorked
            // 
            this.tbStaffHoursWorked.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffHoursWorked.Location = new System.Drawing.Point(484, 72);
            this.tbStaffHoursWorked.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffHoursWorked.Name = "tbStaffHoursWorked";
            this.tbStaffHoursWorked.Size = new System.Drawing.Size(116, 20);
            this.tbStaffHoursWorked.TabIndex = 9;
            this.tbStaffHoursWorked.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStaffHoursWorked_KeyPress_1);
            // 
            // tbStaffWages
            // 
            this.tbStaffWages.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffWages.Location = new System.Drawing.Point(484, 106);
            this.tbStaffWages.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffWages.Name = "tbStaffWages";
            this.tbStaffWages.Size = new System.Drawing.Size(116, 20);
            this.tbStaffWages.TabIndex = 8;
            this.tbStaffWages.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStaffWages_KeyPress_1);
            // 
            // tbStaffPassword
            // 
            this.tbStaffPassword.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffPassword.Location = new System.Drawing.Point(484, 37);
            this.tbStaffPassword.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffPassword.Name = "tbStaffPassword";
            this.tbStaffPassword.Size = new System.Drawing.Size(116, 20);
            this.tbStaffPassword.TabIndex = 7;
            this.tbStaffPassword.UseSystemPasswordChar = true;
            // 
            // tbStaffLastName
            // 
            this.tbStaffLastName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffLastName.Location = new System.Drawing.Point(194, 72);
            this.tbStaffLastName.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffLastName.Name = "tbStaffLastName";
            this.tbStaffLastName.Size = new System.Drawing.Size(116, 20);
            this.tbStaffLastName.TabIndex = 6;
            this.tbStaffLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStaffLastName_KeyPress_1);
            // 
            // tbStaffCellNo
            // 
            this.tbStaffCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffCellNo.Location = new System.Drawing.Point(795, 40);
            this.tbStaffCellNo.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffCellNo.MaxLength = 10;
            this.tbStaffCellNo.Name = "tbStaffCellNo";
            this.tbStaffCellNo.Size = new System.Drawing.Size(116, 20);
            this.tbStaffCellNo.TabIndex = 5;
            this.tbStaffCellNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStaffCellNo_KeyPress_1);
            // 
            // tbStaffFirstName
            // 
            this.tbStaffFirstName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStaffFirstName.Location = new System.Drawing.Point(194, 37);
            this.tbStaffFirstName.Margin = new System.Windows.Forms.Padding(2);
            this.tbStaffFirstName.Name = "tbStaffFirstName";
            this.tbStaffFirstName.Size = new System.Drawing.Size(116, 20);
            this.tbStaffFirstName.TabIndex = 4;
            this.tbStaffFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStaffFirstName_KeyPress_1);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.tbUEmpEmail);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.btUpdateEmployee);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.tbUSWages);
            this.groupBox1.Controls.Add(this.tbUSHWorked);
            this.groupBox1.Controls.Add(this.tbCellNo);
            this.groupBox1.Controls.Add(this.tbUSIDNo);
            this.groupBox1.Controls.Add(this.tbUSLName);
            this.groupBox1.Controls.Add(this.tbUSName);
            this.groupBox1.Controls.Add(this.tbUserID);
            this.groupBox1.Location = new System.Drawing.Point(59, 539);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(1168, 183);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "UPDATE EMPLOYEE DETAILS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(37, 35);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "SELECT EMPLOYEE:";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.BurlyWood;
            this.comboBox1.DataSource = this.employeeBindingSource2;
            this.comboBox1.DisplayMember = "empFirstName";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(194, 31);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(116, 21);
            this.comboBox1.TabIndex = 28;
            // 
            // employeeBindingSource2
            // 
            this.employeeBindingSource2.DataMember = "Employee";
            this.employeeBindingSource2.DataSource = this.group12DataSet;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(621, 74);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "EMPLOYEE EMAIL:";
            // 
            // tbUEmpEmail
            // 
            this.tbUEmpEmail.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUEmpEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "empEmail", true));
            this.tbUEmpEmail.Location = new System.Drawing.Point(747, 71);
            this.tbUEmpEmail.Name = "tbUEmpEmail";
            this.tbUEmpEmail.Size = new System.Drawing.Size(116, 20);
            this.tbUEmpEmail.TabIndex = 27;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1091, 71);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 21;
            this.pictureBox3.TabStop = false;
            this.toolTip3.SetToolTip(this.pictureBox3, "Update An Existing Employee\'s Details");
            // 
            // btUpdateEmployee
            // 
            this.btUpdateEmployee.BackColor = System.Drawing.Color.BurlyWood;
            this.btUpdateEmployee.Location = new System.Drawing.Point(970, 71);
            this.btUpdateEmployee.Margin = new System.Windows.Forms.Padding(2);
            this.btUpdateEmployee.Name = "btUpdateEmployee";
            this.btUpdateEmployee.Size = new System.Drawing.Size(116, 23);
            this.btUpdateEmployee.TabIndex = 20;
            this.btUpdateEmployee.Text = "UPDATE EMPLOYEE";
            this.btUpdateEmployee.UseVisualStyleBackColor = false;
            this.btUpdateEmployee.Click += new System.EventHandler(this.btUpdateEmployee_Click_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(621, 31);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "ENTER WAGES:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(339, 118);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "ENTER HOURS WORKED";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(339, 71);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "EMPLOYEE CELL NO.:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(339, 31);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "ID NUMBER:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 118);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "LAST NAME:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 71);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "FIRST NAME:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(621, 121);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "EMPLOYEE ID:";
            // 
            // tbUSWages
            // 
            this.tbUSWages.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSWages.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "empWages", true));
            this.tbUSWages.Location = new System.Drawing.Point(747, 28);
            this.tbUSWages.Name = "tbUSWages";
            this.tbUSWages.Size = new System.Drawing.Size(116, 20);
            this.tbUSWages.TabIndex = 6;
            this.tbUSWages.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUSWages_KeyPress_1);
            // 
            // tbUSHWorked
            // 
            this.tbUSHWorked.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSHWorked.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource2, "HoursWorked", true));
            this.tbUSHWorked.Location = new System.Drawing.Point(484, 115);
            this.tbUSHWorked.Name = "tbUSHWorked";
            this.tbUSHWorked.Size = new System.Drawing.Size(116, 20);
            this.tbUSHWorked.TabIndex = 5;
            this.tbUSHWorked.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUSHWorked_KeyPress_1);
            // 
            // tbCellNo
            // 
            this.tbCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbCellNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource2, "empCellNo", true));
            this.tbCellNo.Location = new System.Drawing.Point(484, 68);
            this.tbCellNo.MaxLength = 10;
            this.tbCellNo.Name = "tbCellNo";
            this.tbCellNo.Size = new System.Drawing.Size(116, 20);
            this.tbCellNo.TabIndex = 4;
            this.tbCellNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCellNo_KeyPress_1);
            // 
            // tbUSIDNo
            // 
            this.tbUSIDNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSIDNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "empIDNo", true));
            this.tbUSIDNo.Location = new System.Drawing.Point(484, 28);
            this.tbUSIDNo.MaxLength = 13;
            this.tbUSIDNo.Name = "tbUSIDNo";
            this.tbUSIDNo.Size = new System.Drawing.Size(116, 20);
            this.tbUSIDNo.TabIndex = 3;
            this.tbUSIDNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUSIDNo_KeyPress_1);
            // 
            // tbUSLName
            // 
            this.tbUSLName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSLName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource2, "empLastName", true));
            this.tbUSLName.Location = new System.Drawing.Point(194, 115);
            this.tbUSLName.Name = "tbUSLName";
            this.tbUSLName.Size = new System.Drawing.Size(116, 20);
            this.tbUSLName.TabIndex = 2;
            this.tbUSLName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUSLName_KeyPress_1);
            // 
            // tbUSName
            // 
            this.tbUSName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUSName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource2, "empFirstName", true));
            this.tbUSName.Location = new System.Drawing.Point(194, 68);
            this.tbUSName.Name = "tbUSName";
            this.tbUSName.Size = new System.Drawing.Size(116, 20);
            this.tbUSName.TabIndex = 1;
            this.tbUSName.TextChanged += new System.EventHandler(this.tbUSName_TextChanged);
            this.tbUSName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUSName_KeyPress_1);
            // 
            // tbUserID
            // 
            this.tbUserID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUserID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource2, "EmployeeID", true));
            this.tbUserID.Location = new System.Drawing.Point(747, 118);
            this.tbUserID.Name = "tbUserID";
            this.tbUserID.ReadOnly = true;
            this.tbUserID.Size = new System.Drawing.Size(116, 20);
            this.tbUserID.TabIndex = 0;
            this.tbUserID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUserID_KeyPress_1);
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.dsEmployee;
            // 
            // dsEmployee
            // 
            this.dsEmployee.DataSetName = "group12DataSet";
            this.dsEmployee.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taEmployee
            // 
            this.taEmployee.ClearBeforeFill = true;
            // 
            // taStaffSearch
            // 
            this.taStaffSearch.ClearBeforeFill = true;
            // 
            // taAddStaff
            // 
            this.taAddStaff.ClearBeforeFill = true;
            // 
            // taUpdateEmployee
            // 
            this.taUpdateEmployee.ClearBeforeFill = true;
            // 
            // taUpdateAllHoursWorked
            // 
            this.taUpdateAllHoursWorked.ClearBeforeFill = true;
            // 
            // taUpdateAllWages
            // 
            this.taUpdateAllWages.ClearBeforeFill = true;
            // 
            // STAFF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1260, 845);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbStaffDBEdit);
            this.Controls.Add(this.gbStaffdb);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "STAFF";
            this.Text = "STAFF";
            this.Load += new System.EventHandler(this.STAFF_Load);
            this.gbStaffdb.ResumeLayout(false);
            this.gbStaffdb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).EndInit();
            this.gbStaffDBEdit.ResumeLayout(false);
            this.gbStaffDBEdit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbStaffdb;
        private System.Windows.Forms.TextBox tbStaffSearch;
        private System.Windows.Forms.Label labelStaffSearch;
        private System.Windows.Forms.GroupBox gbStaffDBEdit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private group12DataSet dsEmployee;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private group12DataSetTableAdapters.EmployeeTableAdapter taEmployee;
        private group12DataSetTableAdapters.EmployeeTableAdapter taStaffSearch;
        private System.Windows.Forms.TextBox tbStaffID;
        private System.Windows.Forms.TextBox tbStaffHoursWorked;
        private System.Windows.Forms.TextBox tbStaffWages;
        private System.Windows.Forms.TextBox tbStaffPassword;
        private System.Windows.Forms.TextBox tbStaffLastName;
        private System.Windows.Forms.TextBox tbStaffCellNo;
        private System.Windows.Forms.TextBox tbStaffFirstName;
        private System.Windows.Forms.Button btStaffAdd;
        private System.Windows.Forms.Label labelWages;
        private System.Windows.Forms.Label labelSPassword;
        private System.Windows.Forms.Label labelCellNum;
        private System.Windows.Forms.Label labelHoursWorked;
        private System.Windows.Forms.Label labelIDNo;
        private System.Windows.Forms.Label labelLName;
        private System.Windows.Forms.Label labelStaffFName;
        private group12DataSetTableAdapters.EmployeeTableAdapter taAddStaff;
        private group12DataSetTableAdapters.EmployeeTableAdapter taUpdateEmployee;
        private group12DataSetTableAdapters.EmployeeTableAdapter taUpdateAllHoursWorked;
        private group12DataSetTableAdapters.EmployeeTableAdapter taUpdateAllWages;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empFirstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empLastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empIDNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empCellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hoursWorkedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn empWagesDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btUpdateEmployee;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbUSWages;
        private System.Windows.Forms.TextBox tbUSHWorked;
        private System.Windows.Forms.TextBox tbCellNo;
        private System.Windows.Forms.TextBox tbUSIDNo;
        private System.Windows.Forms.TextBox tbUSLName;
        private System.Windows.Forms.TextBox tbUSName;
        private System.Windows.Forms.TextBox tbUserID;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip3;
        private group12DataSet group12DataSet;
        private System.Windows.Forms.BindingSource employeeBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn empEmail;
        private System.Windows.Forms.TextBox tbEmpEmail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource employeeBindingSource2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbUEmpEmail;
    }
}