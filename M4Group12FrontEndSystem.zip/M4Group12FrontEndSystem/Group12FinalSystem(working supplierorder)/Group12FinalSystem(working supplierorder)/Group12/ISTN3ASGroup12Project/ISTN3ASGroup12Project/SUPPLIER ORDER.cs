﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class ORDER : Form
    {
        public ORDER()
        {
            InitializeComponent();
            tafillOrdersTable.Fill(dsSupplierOrder.SupplierOrder);
            tafillOrderItemsTable.Fill(dsSupplierOrder.SupplierOrderItem);
        }

        private void ORDER_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dsSupplierOrder.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.dsSupplierOrder.Employee);
            // TODO: This line of code loads data into the 'group12DataSet.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter.Fill(this.group12DataSet.Supplier);
            // TODO: This line of code loads data into the 'dsSupplierOrder.Inventory' table. You can move, or remove it, as needed.
            this.inventoryTableAdapter.Fill(this.dsSupplierOrder.Inventory);
            // TODO: This line of code loads data into the 'group12DataSet.SupplierOrderItem' table. You can move, or remove it, as needed.
            this.tafillOrderItemsTable.Fill(this.dsSupplierOrder.SupplierOrderItem);
            // TODO: This line of code loads data into the 'group12DataSet.SupplierOrder' table. You can move, or remove it, as needed.
            this.tafillOrdersTable.Fill(this.dsSupplierOrder.SupplierOrder);

        }

        private void btAddOrder_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add an order?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try {
                    DateTime now = DateTime.Now;
                    //taAddOrder.AddOrder(int.Parse(tbOASuppID.Text), int.Parse(tbOAStaffID.Text), now, 0, 00, false);
                    taAddOrder.AddOrder(int.Parse(tbOASuppID.Text), int.Parse(tbOAStaffID.Text), now.ToString(), 0, false);
                    MessageBox.Show("Order added, reload Page to view changes");
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btOIAdd_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add an order item?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    taAddOrderItem.AddOrderItem(int.Parse(tbOIASuppOrderID.Text), int.Parse(tbOIAQuantity.Text),
                    decimal.Parse(tbOIACostPerUnit.Text), tbOIAItemName.Text, int.Parse(tbOIAInvID.Text));
                    taUpdateQuantity.UpdateQuantity(int.Parse(tbOIAQuantity.Text), int.Parse(tbOIASuppOrderID.Text));
                    MessageBox.Show("Order item added, reload Page to view changes");

                }

                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
            }

            else
            {
                MessageBox.Show("Action cancelled");


            }
        }

        private void btOrderComplete_Click(object sender, EventArgs e)
        {
            decimal total = 0;
            DialogResult dr = MessageBox.Show("Do you want to update order status?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                for (int i = 0; i < dsSupplierOrder.SupplierOrderItem.Rows.Count; i++)
                {
                    decimal multiplied = 0;
                    var cellValue = dsSupplierOrder.SupplierOrderItem.Rows[i]["SuppOrderID"];
                    if ((cellValue).ToString() == (tbOrderComplete.Text).ToString())
                    {
                        var temp1 = dsSupplierOrder.SupplierOrderItem.Rows[i]["OrderQuantity"];
                        var temp2 = dsSupplierOrder.SupplierOrderItem.Rows[i]["CostPerUnit"];
                        multiplied = (decimal.Parse(temp1.ToString())) * (decimal.Parse(temp2.ToString()));
                        total += multiplied;

                    }
                }
                //update supply order cost
                taCostUpdate.UpdateOrderTotal(total, int.Parse(tbOrderComplete.Text));
                MessageBox.Show("Updated, reload to view changes");
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            /* decimal total = 0;

             for (int i = 0; i < dsSupplierOrder.SupplierOrderItem.Rows.Count; i++)
             {
                 try
                 {
                     decimal multiplied = 0;
                     var cellValue = dsSupplierOrder.SupplierOrderItem.Rows[i]["SuppOrderID"];
                     if (cellValue.Equals(tbOIASuppOrderID.Text))
                     {
                         multiplied = ((decimal)dsSupplierOrder.SupplierOrderItem.Rows[i]["OrderQuantity"]) * ((decimal)dsSupplierOrder.SupplierOrderItem.Rows[i]["CostPerUnit"]);
                         total += multiplied;
                     }


                 }


                 catch
                 {
                     MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                 }
             }
             //update supply order cost

             taCostUpdate.UpdateOrderTotal(total, int.Parse((tbOIASuppOrderID.Text).ToString()));
            */
         }

         private void btUpdateStatus_Click(object sender, EventArgs e)
         {
             DialogResult dr = MessageBox.Show("Do you want to update order status?", "Confirmation", MessageBoxButtons.YesNo);
             if (dr == DialogResult.Yes)
             {
                 try
                 {
                     taStatusUpdate.UpdateStatus(true, int.Parse(tbStatusUpdate.Text));
                     for (int i = 0; i < dsSupplierOrder.SupplierOrderItem.Rows.Count; i++)
                     {
                         if (int.Parse(tbStatusUpdate.Text) == (int)dsSupplierOrder.SupplierOrderItem.Rows[i]["SuppOrderID"])
                         {
                             var invID = dsSupplierOrder.SupplierOrderItem.Rows[i]["InventoryID"];
                             var quantToBeAdded = dsSupplierOrder.SupplierOrderItem.Rows[i]["OrderQuantity"];
                            //update with  a query using invId as ID
                            for (int j = 0; j < dsSupplierOrder.Inventory.Rows.Count; j++)
                            {
                                var originalInvID = dsSupplierOrder.Inventory.Rows[j]["InventoryID"];
                                if(originalInvID.ToString() == (tbStatusUpdate.Text.ToString()))
                                {
                                    var originalQuantity = dsSupplierOrder.Inventory.Rows[j]["invQuantityAvailable"];
                                    taINVUpdate.UpdateQuantityAvailable(int.Parse(quantToBeAdded.ToString()), int.Parse(originalQuantity.ToString()), int.Parse(invID.ToString()));

                                }
                            }


                           
                        }


                     }
                   /* for (int j = 0; j < dsSupplierOrder.SupplierOrderItem.Rows.Count; j++)
                    {
                        var inventoryID = dsSupplierOrder.SupplierOrderItem.Rows[j]["InventoryID"];
                        for(int k = 0; k < dsSupplierOrder.Inventory.Rows.Count; k++)
                        {
                            var originalInvID = dsSupplierOrder.SupplierOrderItem.Rows[k]["InventoryID"];
                            var quant2 = dsSupplierOrder.SupplierOrderItem.Rows[k]["OrderQuantity"];
                            if (inventoryID == originalInvID)
                            {
                                taUpdateQuantity.UpdateQuantity(int.Parse(quant2.ToString()), int.Parse(inventoryID.ToString()));
                            }
                        }
                    } */
                        MessageBox.Show("Order item status updated, reload Page to view changes");
                 }
                 catch
                 {
                     MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                 }
                 }
             else
             {
                 MessageBox.Show("Action cancelled");
             }
            
        }
    

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            taSeachItem.FillBySearchInv(dsSupplierOrder.Inventory, textBox1.Text);
        }

        private void supplierOrderBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView3_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView3.CurrentRow.Selected = true;
            tbOIAInvID.Text = dataGridView3.Rows[e.RowIndex].Cells[0].Value.ToString();
            tbOIACostPerUnit.Text = dataGridView3.Rows[e.RowIndex].Cells[2].Value.ToString();
            tbOIAItemName.Text = dataGridView3.Rows[e.RowIndex].Cells[1].Value.ToString();
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void tbOASuppID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOAStaffID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIASuppOrderID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIAInvID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIAQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIACostPerUnit_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOrderComplete_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOASuppID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOAStaffID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIASuppOrderID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIAInvID_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbOIAQuantity_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbStatusUpdate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
