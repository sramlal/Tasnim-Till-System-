﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class CUSTOMER_REPORT : Form
    {
        public CUSTOMER_REPORT()
        {
            InitializeComponent();
        }

        private void CUSTOMER_REPORT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Customer' table. You can move, or remove it, as needed.
            this.CustomerTableAdapter.Fill(this.group12DataSet.Customer);

            this.reportViewer1.RefreshReport();
        }
    }
}
