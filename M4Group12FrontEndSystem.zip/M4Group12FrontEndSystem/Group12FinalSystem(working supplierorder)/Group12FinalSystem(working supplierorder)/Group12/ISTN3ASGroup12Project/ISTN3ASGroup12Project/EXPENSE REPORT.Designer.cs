﻿
namespace ISTN3ASGroup12Project
{
    partial class EXPENSE_REPORT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SupplierOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.group12DataSet = new ISTN3ASGroup12Project.group12DataSet();
            this.EmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.expenseReport1 = new ISTN3ASGroup12Project.ExpenseReport();
            this.supplierOrderTableAdapter1 = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderTableAdapter();
            this.supplierTableAdapter1 = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierTableAdapter();
            this.SupplierOrderTableAdapter = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderTableAdapter();
            this.EmployeeTableAdapter = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.ExpenseReport2 = new ISTN3ASGroup12Project.ExpenseReport();
            ((System.ComponentModel.ISupportInitialize)(this.SupplierOrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SupplierOrderBindingSource
            // 
            this.SupplierOrderBindingSource.DataMember = "SupplierOrder";
            this.SupplierOrderBindingSource.DataSource = this.group12DataSet;
            // 
            // group12DataSet
            // 
            this.group12DataSet.DataSetName = "group12DataSet";
            this.group12DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // EmployeeBindingSource
            // 
            this.EmployeeBindingSource.DataMember = "Employee";
            this.EmployeeBindingSource.DataSource = this.group12DataSet;
            // 
            // supplierOrderTableAdapter1
            // 
            this.supplierOrderTableAdapter1.ClearBeforeFill = true;
            // 
            // supplierTableAdapter1
            // 
            this.supplierTableAdapter1.ClearBeforeFill = true;
            // 
            // SupplierOrderTableAdapter
            // 
            this.SupplierOrderTableAdapter.ClearBeforeFill = true;
            // 
            // EmployeeTableAdapter
            // 
            this.EmployeeTableAdapter.ClearBeforeFill = true;
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = 0;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crystalReportViewer1.Location = new System.Drawing.Point(0, 0);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.ReportSource = this.ExpenseReport2;
            this.crystalReportViewer1.Size = new System.Drawing.Size(1241, 772);
            this.crystalReportViewer1.TabIndex = 0;
            this.crystalReportViewer1.Load += new System.EventHandler(this.crystalReportViewer1_Load);
            // 
            // EXPENSE_REPORT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1241, 772);
            this.Controls.Add(this.crystalReportViewer1);
            this.Name = "EXPENSE_REPORT";
            this.Text = "EXPENSE_REPORT";
            this.Load += new System.EventHandler(this.EXPENSE_REPORT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SupplierOrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EmployeeBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource SupplierOrderBindingSource;
        private group12DataSet group12DataSet;
        private System.Windows.Forms.BindingSource EmployeeBindingSource;
        private ExpenseReport expenseReport1;
        private group12DataSetTableAdapters.SupplierOrderTableAdapter supplierOrderTableAdapter1;
        private group12DataSetTableAdapters.SupplierTableAdapter supplierTableAdapter1;
        private group12DataSetTableAdapters.SupplierOrderTableAdapter SupplierOrderTableAdapter;
        private group12DataSetTableAdapters.EmployeeTableAdapter EmployeeTableAdapter;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
        private ExpenseReport ExpenseReport2;
    }
}