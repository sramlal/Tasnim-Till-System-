﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class SUPPLIER_REPORT : Form
    {
        public SUPPLIER_REPORT()
        {
            InitializeComponent();
        }

        private void SUPPLIER_REPORT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Supplier' table. You can move, or remove it, as needed.
            this.SupplierTableAdapter.Fill(this.group12DataSet.Supplier);

            this.reportViewer1.RefreshReport();
        }
    }
}
