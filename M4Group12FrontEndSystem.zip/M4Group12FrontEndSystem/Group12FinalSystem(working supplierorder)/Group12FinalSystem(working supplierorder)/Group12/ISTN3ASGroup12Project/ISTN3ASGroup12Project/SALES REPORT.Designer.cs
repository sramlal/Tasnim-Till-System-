﻿
namespace ISTN3ASGroup12Project
{
    partial class SALES_REPORT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.OrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.group12DataSet = new ISTN3ASGroup12Project.group12DataSet();
            this.OrderTableAdapter = new ISTN3ASGroup12Project.group12DataSetTableAdapters.OrderTableAdapter();
            this.customerTableAdapter1 = new ISTN3ASGroup12Project.group12DataSetTableAdapters.CustomerTableAdapter();
            this.salesReport1 = new ISTN3ASGroup12Project.SalesReport();
            this.salesCrystalReport = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.OrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // OrderBindingSource
            // 
            this.OrderBindingSource.DataMember = "Order";
            this.OrderBindingSource.DataSource = this.group12DataSet;
            // 
            // group12DataSet
            // 
            this.group12DataSet.DataSetName = "group12DataSet";
            this.group12DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // OrderTableAdapter
            // 
            this.OrderTableAdapter.ClearBeforeFill = true;
            // 
            // customerTableAdapter1
            // 
            this.customerTableAdapter1.ClearBeforeFill = true;
            // 
            // salesCrystalReport
            // 
            this.salesCrystalReport.ActiveViewIndex = 0;
            this.salesCrystalReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesCrystalReport.Cursor = System.Windows.Forms.Cursors.Default;
            this.salesCrystalReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.salesCrystalReport.Location = new System.Drawing.Point(0, 0);
            this.salesCrystalReport.Name = "salesCrystalReport";
            this.salesCrystalReport.ReportSource = this.salesReport1;
            this.salesCrystalReport.Size = new System.Drawing.Size(1321, 777);
            this.salesCrystalReport.TabIndex = 0;
            // 
            // SALES_REPORT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1321, 777);
            this.Controls.Add(this.salesCrystalReport);
            this.Name = "SALES_REPORT";
            this.Text = "SALES_REPORT";
            this.Load += new System.EventHandler(this.SALES_REPORT_Load);
            ((System.ComponentModel.ISupportInitialize)(this.OrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource OrderBindingSource;
        private group12DataSet group12DataSet;
        private group12DataSetTableAdapters.OrderTableAdapter OrderTableAdapter;
        private group12DataSetTableAdapters.CustomerTableAdapter customerTableAdapter1;
        private SalesReport salesReport1;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer salesCrystalReport;
    }
}