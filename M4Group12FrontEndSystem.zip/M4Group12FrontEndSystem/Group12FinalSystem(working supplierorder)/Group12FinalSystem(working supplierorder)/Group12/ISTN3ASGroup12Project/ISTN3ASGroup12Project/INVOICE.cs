﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class INVOICE : Form
    {
        public INVOICE()
        {
            InitializeComponent();
            taInvoice.FillByStatus(dsInvoice.SupplierOrder, true);
        }

        private void INVOICE_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.SupplierOrder' table. You can move, or remove it, as needed.
            //this.taInvoice.Fill(this.dsInvoice.SupplierOrder);
            taInvoice.FillByStatus(dsInvoice.SupplierOrder, true);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (tbSearchSuppID.Text == "")
            {
                taInvoice.FillByStatus(dsInvoice.SupplierOrder, true);
            }
            else
            {
                taSearchSuppID.SearchSuppID(dsInvoice.SupplierOrder, int.Parse(tbSearchSuppID.Text));
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
