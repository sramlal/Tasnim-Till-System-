﻿namespace ISTN3ASGroup12Project
{


    partial class group12DataSet
    {
    }
}

namespace ISTN3ASGroup12Project.group12DataSetTableAdapters
{
    partial class EmployeeTableAdapter
    {
    }

    public partial class CustomerTableAdapter {
    }
}
