﻿
namespace ISTN3ASGroup12Project
{
    partial class CUSTOMER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CUSTOMER));
            this.gbCustomerDB = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tbSearchCust = new System.Windows.Forms.TextBox();
            this.labelSearchCust = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.custIDNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custFirstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custLastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custEmailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.custCellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsCustomer = new ISTN3ASGroup12Project.group12DataSet();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btAddCust = new System.Windows.Forms.Button();
            this.tbACLName = new System.Windows.Forms.TextBox();
            this.tbACEmail = new System.Windows.Forms.TextBox();
            this.tbACCellNo = new System.Windows.Forms.TextBox();
            this.tbACPassword = new System.Windows.Forms.TextBox();
            this.tbACName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelCustName = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.customerBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btUpdateCust = new System.Windows.Forms.Button();
            this.tbUCPassword = new System.Windows.Forms.TextBox();
            this.tbUCCellNo = new System.Windows.Forms.TextBox();
            this.tbUCEmail = new System.Windows.Forms.TextBox();
            this.tbUCLName = new System.Windows.Forms.TextBox();
            this.tbUCName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.taCustomer = new ISTN3ASGroup12Project.group12DataSetTableAdapters.CustomerTableAdapter();
            this.taSearchCust = new ISTN3ASGroup12Project.group12DataSetTableAdapters.CustomerTableAdapter();
            this.taAddCust = new ISTN3ASGroup12Project.group12DataSetTableAdapters.CustomerTableAdapter();
            this.taUpdateCust = new ISTN3ASGroup12Project.group12DataSetTableAdapters.CustomerTableAdapter();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.gbCustomerDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // gbCustomerDB
            // 
            this.gbCustomerDB.Controls.Add(this.pictureBox1);
            this.gbCustomerDB.Controls.Add(this.tbSearchCust);
            this.gbCustomerDB.Controls.Add(this.labelSearchCust);
            this.gbCustomerDB.Controls.Add(this.dataGridView1);
            this.gbCustomerDB.Location = new System.Drawing.Point(26, 20);
            this.gbCustomerDB.Margin = new System.Windows.Forms.Padding(2);
            this.gbCustomerDB.Name = "gbCustomerDB";
            this.gbCustomerDB.Padding = new System.Windows.Forms.Padding(2);
            this.gbCustomerDB.Size = new System.Drawing.Size(1036, 312);
            this.gbCustomerDB.TabIndex = 0;
            this.gbCustomerDB.TabStop = false;
            this.gbCustomerDB.Text = "CUSTOMER DATABASE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(705, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Search For A Customer In The Database");
            // 
            // tbSearchCust
            // 
            this.tbSearchCust.BackColor = System.Drawing.Color.BurlyWood;
            this.tbSearchCust.Location = new System.Drawing.Point(540, 17);
            this.tbSearchCust.Margin = new System.Windows.Forms.Padding(2);
            this.tbSearchCust.Name = "tbSearchCust";
            this.tbSearchCust.Size = new System.Drawing.Size(160, 20);
            this.tbSearchCust.TabIndex = 2;
            this.tbSearchCust.TextChanged += new System.EventHandler(this.tbSearchCust_TextChanged);
            // 
            // labelSearchCust
            // 
            this.labelSearchCust.AutoSize = true;
            this.labelSearchCust.Location = new System.Drawing.Point(359, 20);
            this.labelSearchCust.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSearchCust.Name = "labelSearchCust";
            this.labelSearchCust.Size = new System.Drawing.Size(152, 13);
            this.labelSearchCust.TabIndex = 1;
            this.labelSearchCust.Text = "SEARCH CUSTOMER NAME:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.custIDNoDataGridViewTextBoxColumn,
            this.custFirstNameDataGridViewTextBoxColumn,
            this.custLastNameDataGridViewTextBoxColumn,
            this.custEmailDataGridViewTextBoxColumn,
            this.custCellNoDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.customerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(28, 44);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(977, 247);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
            // 
            // custIDNoDataGridViewTextBoxColumn
            // 
            this.custIDNoDataGridViewTextBoxColumn.DataPropertyName = "CustIDNo";
            this.custIDNoDataGridViewTextBoxColumn.HeaderText = "CustIDNo";
            this.custIDNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custIDNoDataGridViewTextBoxColumn.Name = "custIDNoDataGridViewTextBoxColumn";
            this.custIDNoDataGridViewTextBoxColumn.ReadOnly = true;
            this.custIDNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // custFirstNameDataGridViewTextBoxColumn
            // 
            this.custFirstNameDataGridViewTextBoxColumn.DataPropertyName = "custFirstName";
            this.custFirstNameDataGridViewTextBoxColumn.HeaderText = "custFirstName";
            this.custFirstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custFirstNameDataGridViewTextBoxColumn.Name = "custFirstNameDataGridViewTextBoxColumn";
            this.custFirstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // custLastNameDataGridViewTextBoxColumn
            // 
            this.custLastNameDataGridViewTextBoxColumn.DataPropertyName = "custLastName";
            this.custLastNameDataGridViewTextBoxColumn.HeaderText = "custLastName";
            this.custLastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custLastNameDataGridViewTextBoxColumn.Name = "custLastNameDataGridViewTextBoxColumn";
            this.custLastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // custEmailDataGridViewTextBoxColumn
            // 
            this.custEmailDataGridViewTextBoxColumn.DataPropertyName = "custEmail";
            this.custEmailDataGridViewTextBoxColumn.HeaderText = "custEmail";
            this.custEmailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custEmailDataGridViewTextBoxColumn.Name = "custEmailDataGridViewTextBoxColumn";
            this.custEmailDataGridViewTextBoxColumn.Width = 125;
            // 
            // custCellNoDataGridViewTextBoxColumn
            // 
            this.custCellNoDataGridViewTextBoxColumn.DataPropertyName = "custCellNo";
            this.custCellNoDataGridViewTextBoxColumn.HeaderText = "custCellNo";
            this.custCellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.custCellNoDataGridViewTextBoxColumn.Name = "custCellNoDataGridViewTextBoxColumn";
            this.custCellNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.dsCustomer;
            // 
            // dsCustomer
            // 
            this.dsCustomer.DataSetName = "group12DataSet";
            this.dsCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.btAddCust);
            this.groupBox1.Controls.Add(this.tbACLName);
            this.groupBox1.Controls.Add(this.tbACEmail);
            this.groupBox1.Controls.Add(this.tbACCellNo);
            this.groupBox1.Controls.Add(this.tbACPassword);
            this.groupBox1.Controls.Add(this.tbACName);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.labelCustName);
            this.groupBox1.Location = new System.Drawing.Point(26, 357);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(1036, 206);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ADD CUSTOMER TO DATABASE";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(854, 137);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            this.toolTip2.SetToolTip(this.pictureBox2, "Add A Customer To The Database");
            // 
            // btAddCust
            // 
            this.btAddCust.BackColor = System.Drawing.Color.BurlyWood;
            this.btAddCust.Location = new System.Drawing.Point(735, 137);
            this.btAddCust.Margin = new System.Windows.Forms.Padding(2);
            this.btAddCust.Name = "btAddCust";
            this.btAddCust.Size = new System.Drawing.Size(114, 26);
            this.btAddCust.TabIndex = 13;
            this.btAddCust.Text = "ADD CUSTOMER";
            this.btAddCust.UseVisualStyleBackColor = false;
            this.btAddCust.Click += new System.EventHandler(this.btAddCust_Click);
            // 
            // tbACLName
            // 
            this.tbACLName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbACLName.Location = new System.Drawing.Point(302, 94);
            this.tbACLName.Margin = new System.Windows.Forms.Padding(2);
            this.tbACLName.Name = "tbACLName";
            this.tbACLName.Size = new System.Drawing.Size(144, 20);
            this.tbACLName.TabIndex = 12;
            this.tbACLName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbACLName_KeyPress_1);
            // 
            // tbACEmail
            // 
            this.tbACEmail.BackColor = System.Drawing.Color.BurlyWood;
            this.tbACEmail.Location = new System.Drawing.Point(302, 148);
            this.tbACEmail.Margin = new System.Windows.Forms.Padding(2);
            this.tbACEmail.Name = "tbACEmail";
            this.tbACEmail.Size = new System.Drawing.Size(144, 20);
            this.tbACEmail.TabIndex = 11;
            this.tbACEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbACEmail_KeyPress);
            // 
            // tbACCellNo
            // 
            this.tbACCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbACCellNo.Location = new System.Drawing.Point(727, 43);
            this.tbACCellNo.Margin = new System.Windows.Forms.Padding(2);
            this.tbACCellNo.MaxLength = 10;
            this.tbACCellNo.Name = "tbACCellNo";
            this.tbACCellNo.Size = new System.Drawing.Size(144, 20);
            this.tbACCellNo.TabIndex = 10;
            this.tbACCellNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbACCellNo_KeyPress_1);
            // 
            // tbACPassword
            // 
            this.tbACPassword.BackColor = System.Drawing.Color.BurlyWood;
            this.tbACPassword.Location = new System.Drawing.Point(727, 94);
            this.tbACPassword.Margin = new System.Windows.Forms.Padding(2);
            this.tbACPassword.Name = "tbACPassword";
            this.tbACPassword.Size = new System.Drawing.Size(144, 20);
            this.tbACPassword.TabIndex = 9;
            this.tbACPassword.UseSystemPasswordChar = true;
            this.tbACPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbACPassword_KeyPress);
            // 
            // tbACName
            // 
            this.tbACName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbACName.Location = new System.Drawing.Point(302, 39);
            this.tbACName.Margin = new System.Windows.Forms.Padding(2);
            this.tbACName.Name = "tbACName";
            this.tbACName.Size = new System.Drawing.Size(144, 20);
            this.tbACName.TabIndex = 7;
            this.tbACName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbACName_KeyPress_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(530, 46);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(190, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "ENTER CUSTOMER CELL NUMBER:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(113, 94);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "ENTER CUSTOMER SURNAME:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 148);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "ENTER CUSTOMER EMAIL:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(530, 97);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "ENTER CUSTOMER PASSWORD:";
            // 
            // labelCustName
            // 
            this.labelCustName.AutoSize = true;
            this.labelCustName.Location = new System.Drawing.Point(135, 43);
            this.labelCustName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCustName.Name = "labelCustName";
            this.labelCustName.Size = new System.Drawing.Size(145, 13);
            this.labelCustName.TabIndex = 2;
            this.labelCustName.Text = "ENTER CUSTOMER NAME:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.btUpdateCust);
            this.groupBox2.Controls.Add(this.tbUCPassword);
            this.groupBox2.Controls.Add(this.tbUCCellNo);
            this.groupBox2.Controls.Add(this.tbUCEmail);
            this.groupBox2.Controls.Add(this.tbUCLName);
            this.groupBox2.Controls.Add(this.tbUCName);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(26, 579);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(1036, 141);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "UPDATE CUSTOMER DETAILS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(164, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "SELECT CUSTOMER:";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.BurlyWood;
            this.comboBox1.DataSource = this.customerBindingSource1;
            this.comboBox1.DisplayMember = "custFirstName";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(302, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(144, 21);
            this.comboBox1.TabIndex = 16;
            // 
            // customerBindingSource1
            // 
            this.customerBindingSource1.DataMember = "Customer";
            this.customerBindingSource1.DataSource = this.dsCustomer;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(882, 104);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            this.toolTip3.SetToolTip(this.pictureBox3, "Update An Existing Customer In The Database");
            // 
            // btUpdateCust
            // 
            this.btUpdateCust.BackColor = System.Drawing.Color.BurlyWood;
            this.btUpdateCust.Location = new System.Drawing.Point(735, 103);
            this.btUpdateCust.Margin = new System.Windows.Forms.Padding(2);
            this.btUpdateCust.Name = "btUpdateCust";
            this.btUpdateCust.Size = new System.Drawing.Size(142, 23);
            this.btUpdateCust.TabIndex = 15;
            this.btUpdateCust.Text = "UPDATE CUSTOMER";
            this.btUpdateCust.UseVisualStyleBackColor = false;
            this.btUpdateCust.Click += new System.EventHandler(this.btUpdateCust_Click);
            // 
            // tbUCPassword
            // 
            this.tbUCPassword.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUCPassword.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "custPassword", true));
            this.tbUCPassword.Location = new System.Drawing.Point(735, 76);
            this.tbUCPassword.Margin = new System.Windows.Forms.Padding(2);
            this.tbUCPassword.Name = "tbUCPassword";
            this.tbUCPassword.Size = new System.Drawing.Size(144, 20);
            this.tbUCPassword.TabIndex = 14;
            this.tbUCPassword.UseSystemPasswordChar = true;
            this.tbUCPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUCPassword_KeyPress);
            // 
            // tbUCCellNo
            // 
            this.tbUCCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUCCellNo.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "custCellNo", true));
            this.tbUCCellNo.Location = new System.Drawing.Point(735, 45);
            this.tbUCCellNo.Margin = new System.Windows.Forms.Padding(2);
            this.tbUCCellNo.MaxLength = 10;
            this.tbUCCellNo.Name = "tbUCCellNo";
            this.tbUCCellNo.Size = new System.Drawing.Size(144, 20);
            this.tbUCCellNo.TabIndex = 13;
            this.tbUCCellNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUCCellNo_KeyPress_1);
            // 
            // tbUCEmail
            // 
            this.tbUCEmail.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUCEmail.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "custEmail", true));
            this.tbUCEmail.Location = new System.Drawing.Point(302, 104);
            this.tbUCEmail.Margin = new System.Windows.Forms.Padding(2);
            this.tbUCEmail.Name = "tbUCEmail";
            this.tbUCEmail.Size = new System.Drawing.Size(144, 20);
            this.tbUCEmail.TabIndex = 12;
            this.tbUCEmail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUCEmail_KeyPress);
            // 
            // tbUCLName
            // 
            this.tbUCLName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUCLName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "custLastName", true));
            this.tbUCLName.Location = new System.Drawing.Point(302, 77);
            this.tbUCLName.Margin = new System.Windows.Forms.Padding(2);
            this.tbUCLName.Name = "tbUCLName";
            this.tbUCLName.Size = new System.Drawing.Size(144, 20);
            this.tbUCLName.TabIndex = 11;
            this.tbUCLName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUCLName_KeyPress_1);
            // 
            // tbUCName
            // 
            this.tbUCName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbUCName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource1, "custFirstName", true));
            this.tbUCName.Location = new System.Drawing.Point(302, 47);
            this.tbUCName.Margin = new System.Windows.Forms.Padding(2);
            this.tbUCName.Name = "tbUCName";
            this.tbUCName.Size = new System.Drawing.Size(144, 20);
            this.tbUCName.TabIndex = 10;
            this.tbUCName.TextChanged += new System.EventHandler(this.tbUCName_TextChanged);
            this.tbUCName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUCName_KeyPress_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(550, 76);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(177, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "ENTER CUSTOMER PASSWORD:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(530, 45);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(190, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "ENTER CUSTOMER CELL NUMBER:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(134, 108);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "ENTER CUSTOMER EMAIL:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 80);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "ENTER CUSTOMER SURNAME:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(134, 51);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "ENTER CUSTOMER NAME:";
            // 
            // taCustomer
            // 
            this.taCustomer.ClearBeforeFill = true;
            // 
            // taSearchCust
            // 
            this.taSearchCust.ClearBeforeFill = true;
            // 
            // taAddCust
            // 
            this.taAddCust.ClearBeforeFill = true;
            // 
            // taUpdateCust
            // 
            this.taUpdateCust.ClearBeforeFill = true;
            // 
            // CUSTOMER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1100, 802);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbCustomerDB);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CUSTOMER";
            this.Text = "CUSTOMER";
            this.Load += new System.EventHandler(this.CUSTOMER_Load);
            this.gbCustomerDB.ResumeLayout(false);
            this.gbCustomerDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbCustomerDB;
        private System.Windows.Forms.DataGridView dataGridView1;
        private group12DataSet dsCustomer;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private group12DataSetTableAdapters.CustomerTableAdapter taCustomer;
        private System.Windows.Forms.TextBox tbSearchCust;
        private System.Windows.Forms.Label labelSearchCust;
        private group12DataSetTableAdapters.CustomerTableAdapter taSearchCust;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelCustName;
        private System.Windows.Forms.Button btAddCust;
        private System.Windows.Forms.TextBox tbACLName;
        private System.Windows.Forms.TextBox tbACEmail;
        private System.Windows.Forms.TextBox tbACCellNo;
        private System.Windows.Forms.TextBox tbACPassword;
        private System.Windows.Forms.TextBox tbACName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private group12DataSetTableAdapters.CustomerTableAdapter taAddCust;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbUCCellNo;
        private System.Windows.Forms.TextBox tbUCEmail;
        private System.Windows.Forms.TextBox tbUCLName;
        private System.Windows.Forms.TextBox tbUCName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btUpdateCust;
        private System.Windows.Forms.TextBox tbUCPassword;
        private group12DataSetTableAdapters.CustomerTableAdapter taUpdateCust;
        private System.Windows.Forms.DataGridViewTextBoxColumn custIDNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custFirstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custLastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custEmailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn custCellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource customerBindingSource1;
        private System.Windows.Forms.Label label10;
    }
}