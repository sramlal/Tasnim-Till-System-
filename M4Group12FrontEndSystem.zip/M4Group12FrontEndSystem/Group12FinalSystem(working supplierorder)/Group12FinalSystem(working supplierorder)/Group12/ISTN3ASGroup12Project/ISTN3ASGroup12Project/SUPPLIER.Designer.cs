﻿
namespace ISTN3ASGroup12Project
{
    partial class SUPPLIER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SUPPLIER));
            this.tcSupplier = new System.Windows.Forms.TabControl();
            this.tcSupplierdb = new System.Windows.Forms.TabPage();
            this.gbEditSupplierDB = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btAddSupp = new System.Windows.Forms.Button();
            this.labelSuppPostalCode = new System.Windows.Forms.Label();
            this.labelSuppAddress = new System.Windows.Forms.Label();
            this.labelSuppCellNo = new System.Windows.Forms.Label();
            this.labelSuppName = new System.Windows.Forms.Label();
            this.tbSuppPostalCode = new System.Windows.Forms.TextBox();
            this.tbSuppCellNo = new System.Windows.Forms.TextBox();
            this.tbSuppAddress = new System.Windows.Forms.TextBox();
            this.tbSuppName = new System.Windows.Forms.TextBox();
            this.gbSupplierDatabase = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tbSupplierSearch = new System.Windows.Forms.TextBox();
            this.labelSupplierSearch = new System.Windows.Forms.Label();
            this.dgvSupplierdb = new System.Windows.Forms.DataGridView();
            this.supplierIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppCellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppPostalCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSupplier = new ISTN3ASGroup12Project.group12DataSet();
            this.taSupplier = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierTableAdapter();
            this.taSupplierSearch = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierTableAdapter();
            this.taAddSupplier = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierTableAdapter();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.tcSupplier.SuspendLayout();
            this.tcSupplierdb.SuspendLayout();
            this.gbEditSupplierDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.gbSupplierDatabase.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplierdb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // tcSupplier
            // 
            this.tcSupplier.Controls.Add(this.tcSupplierdb);
            this.tcSupplier.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcSupplier.Location = new System.Drawing.Point(0, 0);
            this.tcSupplier.Margin = new System.Windows.Forms.Padding(2);
            this.tcSupplier.Name = "tcSupplier";
            this.tcSupplier.SelectedIndex = 0;
            this.tcSupplier.Size = new System.Drawing.Size(1039, 587);
            this.tcSupplier.TabIndex = 0;
            // 
            // tcSupplierdb
            // 
            this.tcSupplierdb.BackColor = System.Drawing.Color.Azure;
            this.tcSupplierdb.Controls.Add(this.gbEditSupplierDB);
            this.tcSupplierdb.Controls.Add(this.gbSupplierDatabase);
            this.tcSupplierdb.Location = new System.Drawing.Point(4, 22);
            this.tcSupplierdb.Margin = new System.Windows.Forms.Padding(2);
            this.tcSupplierdb.Name = "tcSupplierdb";
            this.tcSupplierdb.Padding = new System.Windows.Forms.Padding(2);
            this.tcSupplierdb.Size = new System.Drawing.Size(1031, 561);
            this.tcSupplierdb.TabIndex = 0;
            this.tcSupplierdb.Text = "SUPPLIER DATABASE";
            // 
            // gbEditSupplierDB
            // 
            this.gbEditSupplierDB.Controls.Add(this.pictureBox2);
            this.gbEditSupplierDB.Controls.Add(this.btAddSupp);
            this.gbEditSupplierDB.Controls.Add(this.labelSuppPostalCode);
            this.gbEditSupplierDB.Controls.Add(this.labelSuppAddress);
            this.gbEditSupplierDB.Controls.Add(this.labelSuppCellNo);
            this.gbEditSupplierDB.Controls.Add(this.labelSuppName);
            this.gbEditSupplierDB.Controls.Add(this.tbSuppPostalCode);
            this.gbEditSupplierDB.Controls.Add(this.tbSuppCellNo);
            this.gbEditSupplierDB.Controls.Add(this.tbSuppAddress);
            this.gbEditSupplierDB.Controls.Add(this.tbSuppName);
            this.gbEditSupplierDB.Location = new System.Drawing.Point(139, 317);
            this.gbEditSupplierDB.Margin = new System.Windows.Forms.Padding(2);
            this.gbEditSupplierDB.Name = "gbEditSupplierDB";
            this.gbEditSupplierDB.Padding = new System.Windows.Forms.Padding(2);
            this.gbEditSupplierDB.Size = new System.Drawing.Size(795, 155);
            this.gbEditSupplierDB.TabIndex = 1;
            this.gbEditSupplierDB.TabStop = false;
            this.gbEditSupplierDB.Text = "ADD SUPPLIER TO DATABASE";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(340, 112);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.toolTip2.SetToolTip(this.pictureBox2, "Add New Supplier To Database ");
            // 
            // btAddSupp
            // 
            this.btAddSupp.BackColor = System.Drawing.Color.BurlyWood;
            this.btAddSupp.Location = new System.Drawing.Point(226, 115);
            this.btAddSupp.Margin = new System.Windows.Forms.Padding(2);
            this.btAddSupp.Name = "btAddSupp";
            this.btAddSupp.Size = new System.Drawing.Size(103, 19);
            this.btAddSupp.TabIndex = 8;
            this.btAddSupp.Text = "ADD SUPPLIER";
            this.btAddSupp.UseVisualStyleBackColor = false;
            this.btAddSupp.Click += new System.EventHandler(this.btAddSupp_Click);
            // 
            // labelSuppPostalCode
            // 
            this.labelSuppPostalCode.AutoSize = true;
            this.labelSuppPostalCode.Location = new System.Drawing.Point(364, 67);
            this.labelSuppPostalCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSuppPostalCode.Name = "labelSuppPostalCode";
            this.labelSuppPostalCode.Size = new System.Drawing.Size(149, 13);
            this.labelSuppPostalCode.TabIndex = 7;
            this.labelSuppPostalCode.Text = "SUPPLIER POSTAL CODDE:";
            // 
            // labelSuppAddress
            // 
            this.labelSuppAddress.AutoSize = true;
            this.labelSuppAddress.Location = new System.Drawing.Point(364, 28);
            this.labelSuppAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSuppAddress.Name = "labelSuppAddress";
            this.labelSuppAddress.Size = new System.Drawing.Size(118, 13);
            this.labelSuppAddress.TabIndex = 6;
            this.labelSuppAddress.Text = "SUPPLIER ADDRESS:";
            // 
            // labelSuppCellNo
            // 
            this.labelSuppCellNo.AutoSize = true;
            this.labelSuppCellNo.Location = new System.Drawing.Point(17, 67);
            this.labelSuppCellNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSuppCellNo.Name = "labelSuppCellNo";
            this.labelSuppCellNo.Size = new System.Drawing.Size(142, 13);
            this.labelSuppCellNo.TabIndex = 5;
            this.labelSuppCellNo.Text = "SUPPLIER CELL NUMBER:";
            // 
            // labelSuppName
            // 
            this.labelSuppName.AutoSize = true;
            this.labelSuppName.Location = new System.Drawing.Point(17, 32);
            this.labelSuppName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSuppName.Name = "labelSuppName";
            this.labelSuppName.Size = new System.Drawing.Size(97, 13);
            this.labelSuppName.TabIndex = 4;
            this.labelSuppName.Text = "SUPPLIER NAME:";
            // 
            // tbSuppPostalCode
            // 
            this.tbSuppPostalCode.BackColor = System.Drawing.Color.BurlyWood;
            this.tbSuppPostalCode.Location = new System.Drawing.Point(519, 64);
            this.tbSuppPostalCode.Margin = new System.Windows.Forms.Padding(2);
            this.tbSuppPostalCode.MaxLength = 4;
            this.tbSuppPostalCode.Name = "tbSuppPostalCode";
            this.tbSuppPostalCode.Size = new System.Drawing.Size(132, 20);
            this.tbSuppPostalCode.TabIndex = 3;
            this.tbSuppPostalCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSuppPostalCode_KeyPress_1);
            // 
            // tbSuppCellNo
            // 
            this.tbSuppCellNo.BackColor = System.Drawing.Color.BurlyWood;
            this.tbSuppCellNo.Location = new System.Drawing.Point(157, 64);
            this.tbSuppCellNo.Margin = new System.Windows.Forms.Padding(2);
            this.tbSuppCellNo.MaxLength = 10;
            this.tbSuppCellNo.Name = "tbSuppCellNo";
            this.tbSuppCellNo.Size = new System.Drawing.Size(132, 20);
            this.tbSuppCellNo.TabIndex = 2;
            this.tbSuppCellNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSuppCellNo_KeyPress_1);
            // 
            // tbSuppAddress
            // 
            this.tbSuppAddress.BackColor = System.Drawing.Color.BurlyWood;
            this.tbSuppAddress.Location = new System.Drawing.Point(519, 26);
            this.tbSuppAddress.Margin = new System.Windows.Forms.Padding(2);
            this.tbSuppAddress.Name = "tbSuppAddress";
            this.tbSuppAddress.Size = new System.Drawing.Size(132, 20);
            this.tbSuppAddress.TabIndex = 1;
            // 
            // tbSuppName
            // 
            this.tbSuppName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbSuppName.Location = new System.Drawing.Point(157, 28);
            this.tbSuppName.Margin = new System.Windows.Forms.Padding(2);
            this.tbSuppName.Name = "tbSuppName";
            this.tbSuppName.Size = new System.Drawing.Size(132, 20);
            this.tbSuppName.TabIndex = 0;
            this.tbSuppName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSuppName_KeyPress_1);
            // 
            // gbSupplierDatabase
            // 
            this.gbSupplierDatabase.Controls.Add(this.pictureBox1);
            this.gbSupplierDatabase.Controls.Add(this.tbSupplierSearch);
            this.gbSupplierDatabase.Controls.Add(this.labelSupplierSearch);
            this.gbSupplierDatabase.Controls.Add(this.dgvSupplierdb);
            this.gbSupplierDatabase.Location = new System.Drawing.Point(139, 17);
            this.gbSupplierDatabase.Margin = new System.Windows.Forms.Padding(2);
            this.gbSupplierDatabase.Name = "gbSupplierDatabase";
            this.gbSupplierDatabase.Padding = new System.Windows.Forms.Padding(2);
            this.gbSupplierDatabase.Size = new System.Drawing.Size(795, 284);
            this.gbSupplierDatabase.TabIndex = 0;
            this.gbSupplierDatabase.TabStop = false;
            this.gbSupplierDatabase.Text = "SUPPLIER DATABASE";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(507, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Search For Supplier");
            // 
            // tbSupplierSearch
            // 
            this.tbSupplierSearch.BackColor = System.Drawing.Color.BurlyWood;
            this.tbSupplierSearch.Location = new System.Drawing.Point(340, 23);
            this.tbSupplierSearch.Margin = new System.Windows.Forms.Padding(2);
            this.tbSupplierSearch.Name = "tbSupplierSearch";
            this.tbSupplierSearch.Size = new System.Drawing.Size(162, 20);
            this.tbSupplierSearch.TabIndex = 2;
            this.tbSupplierSearch.TextChanged += new System.EventHandler(this.tbSupplierSearch_TextChanged);
            // 
            // labelSupplierSearch
            // 
            this.labelSupplierSearch.AutoSize = true;
            this.labelSupplierSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSupplierSearch.Location = new System.Drawing.Point(182, 24);
            this.labelSupplierSearch.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSupplierSearch.Name = "labelSupplierSearch";
            this.labelSupplierSearch.Size = new System.Drawing.Size(152, 15);
            this.labelSupplierSearch.TabIndex = 1;
            this.labelSupplierSearch.Text = "ENTER SUPPLIER NAME:";
            // 
            // dgvSupplierdb
            // 
            this.dgvSupplierdb.AutoGenerateColumns = false;
            this.dgvSupplierdb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSupplierdb.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplierIDDataGridViewTextBoxColumn,
            this.suppNameDataGridViewTextBoxColumn,
            this.suppCellNoDataGridViewTextBoxColumn,
            this.suppAddressDataGridViewTextBoxColumn,
            this.suppPostalCodeDataGridViewTextBoxColumn});
            this.dgvSupplierdb.DataSource = this.supplierBindingSource;
            this.dgvSupplierdb.Location = new System.Drawing.Point(62, 46);
            this.dgvSupplierdb.Margin = new System.Windows.Forms.Padding(2);
            this.dgvSupplierdb.Name = "dgvSupplierdb";
            this.dgvSupplierdb.RowHeadersWidth = 51;
            this.dgvSupplierdb.RowTemplate.Height = 24;
            this.dgvSupplierdb.Size = new System.Drawing.Size(676, 226);
            this.dgvSupplierdb.TabIndex = 0;
            // 
            // supplierIDDataGridViewTextBoxColumn
            // 
            this.supplierIDDataGridViewTextBoxColumn.DataPropertyName = "SupplierID";
            this.supplierIDDataGridViewTextBoxColumn.HeaderText = "SupplierID";
            this.supplierIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplierIDDataGridViewTextBoxColumn.Name = "supplierIDDataGridViewTextBoxColumn";
            this.supplierIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.supplierIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // suppNameDataGridViewTextBoxColumn
            // 
            this.suppNameDataGridViewTextBoxColumn.DataPropertyName = "suppName";
            this.suppNameDataGridViewTextBoxColumn.HeaderText = "suppName";
            this.suppNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppNameDataGridViewTextBoxColumn.Name = "suppNameDataGridViewTextBoxColumn";
            this.suppNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // suppCellNoDataGridViewTextBoxColumn
            // 
            this.suppCellNoDataGridViewTextBoxColumn.DataPropertyName = "suppCellNo";
            this.suppCellNoDataGridViewTextBoxColumn.HeaderText = "suppCellNo";
            this.suppCellNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppCellNoDataGridViewTextBoxColumn.Name = "suppCellNoDataGridViewTextBoxColumn";
            this.suppCellNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // suppAddressDataGridViewTextBoxColumn
            // 
            this.suppAddressDataGridViewTextBoxColumn.DataPropertyName = "suppAddress";
            this.suppAddressDataGridViewTextBoxColumn.HeaderText = "suppAddress";
            this.suppAddressDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppAddressDataGridViewTextBoxColumn.Name = "suppAddressDataGridViewTextBoxColumn";
            this.suppAddressDataGridViewTextBoxColumn.Width = 125;
            // 
            // suppPostalCodeDataGridViewTextBoxColumn
            // 
            this.suppPostalCodeDataGridViewTextBoxColumn.DataPropertyName = "suppPostalCode";
            this.suppPostalCodeDataGridViewTextBoxColumn.HeaderText = "suppPostalCode";
            this.suppPostalCodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppPostalCodeDataGridViewTextBoxColumn.Name = "suppPostalCodeDataGridViewTextBoxColumn";
            this.suppPostalCodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.dsSupplier;
            // 
            // dsSupplier
            // 
            this.dsSupplier.DataSetName = "group12DataSet";
            this.dsSupplier.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // taSupplier
            // 
            this.taSupplier.ClearBeforeFill = true;
            // 
            // taSupplierSearch
            // 
            this.taSupplierSearch.ClearBeforeFill = true;
            // 
            // taAddSupplier
            // 
            this.taAddSupplier.ClearBeforeFill = true;
            // 
            // SUPPLIER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Olive;
            this.ClientSize = new System.Drawing.Size(1039, 587);
            this.Controls.Add(this.tcSupplier);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "SUPPLIER";
            this.Text = "SUPPLIER";
            this.Load += new System.EventHandler(this.Supplier_Load);
            this.tcSupplier.ResumeLayout(false);
            this.tcSupplierdb.ResumeLayout(false);
            this.gbEditSupplierDB.ResumeLayout(false);
            this.gbEditSupplierDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.gbSupplierDatabase.ResumeLayout(false);
            this.gbSupplierDatabase.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplierdb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSupplier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcSupplier;
        private System.Windows.Forms.TabPage tcSupplierdb;
        private System.Windows.Forms.GroupBox gbSupplierDatabase;
        private System.Windows.Forms.DataGridView dgvSupplierdb;
        private group12DataSet dsSupplier;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private group12DataSetTableAdapters.SupplierTableAdapter taSupplier;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppCellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppPostalCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox gbEditSupplierDB;
        private System.Windows.Forms.Button btAddSupp;
        private System.Windows.Forms.Label labelSuppPostalCode;
        private System.Windows.Forms.Label labelSuppAddress;
        private System.Windows.Forms.Label labelSuppCellNo;
        private System.Windows.Forms.Label labelSuppName;
        private System.Windows.Forms.TextBox tbSuppPostalCode;
        private System.Windows.Forms.TextBox tbSuppCellNo;
        private System.Windows.Forms.TextBox tbSuppAddress;
        private System.Windows.Forms.TextBox tbSuppName;
        private System.Windows.Forms.TextBox tbSupplierSearch;
        private System.Windows.Forms.Label labelSupplierSearch;
        private group12DataSetTableAdapters.SupplierTableAdapter taSupplierSearch;
        private group12DataSetTableAdapters.SupplierTableAdapter taAddSupplier;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}