﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Staff
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tbStaffSearch_TextChanged(object sender, EventArgs e)
        {
           employeeTableAdapter.FillBy(group12DataSet.Employee, tbStaffSearch.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.group12DataSet.Employee);

        }

        private void btStaffAdd_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add employee?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    employeeTableAdapter.InsertQuery(tbStaffFirstName.Text, tbStaffLastName.Text, tbStaffID.Text,
                    tbStaffCellNo.Text, "", double.Parse(tbStaffHoursWorked.Text), decimal.Parse(tbStaffWages.Text));
                    MessageBox.Show("Employee added to database, reload page to view changes.");
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
            }

            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbStaffFirstName.Text = ""; tbStaffLastName.Text = ""; tbStaffID.Text = "";
            tbStaffCellNo.Text = ""; tbStaffHoursWorked.Text = ""; tbStaffWages.Text = "";

        }

        private void btUpdateEmployee_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update employee?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    employeeTableAdapter.UpdateQuery(tbUSName.Text, tbUSLName.Text, tbUSIDNo.Text, tbCellNo.Text, "", 
                    double.Parse(tbUSHWorked.Text), decimal.Parse(tbUSWages.Text), int.Parse(tbUserID.Text), int.Parse(tbUserID.Text)) ;
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbUSHWorked.Text = ""; tbUSWages.Text = "";
            tbUSName.Text = ""; tbUSLName.Text = ""; tbUSIDNo.Text = ""; tbUserID.Text = ""; tbCellNo.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.CurrentRow.Selected = true;
            tbUserID.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            tbUSName.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            tbUSLName.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            tbUSIDNo.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            tbCellNo.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
            tbUSHWorked.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
            tbUSWages.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
        }
    }
}
