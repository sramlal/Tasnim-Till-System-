﻿
namespace ISTN3ASGroup12Project
{
    partial class ORDER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ORDER));
            this.gbOrders = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SuppOrderID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateOrderedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.supplierOrderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSupplierOrder = new ISTN3ASGroup12Project.group12DataSet();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.suppOrderItemIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppOrderIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventoryIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costPerUnitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierOrderItemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tbOrderComplete = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btOIAdd = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btOrderComplete = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btAddOrder = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbOIACostPerUnit = new System.Windows.Forms.TextBox();
            this.tbOIASuppOrderID = new System.Windows.Forms.TextBox();
            this.tbOIAQuantity = new System.Windows.Forms.TextBox();
            this.tbOIAItemName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labeOASuppID = new System.Windows.Forms.Label();
            this.tbOIAInvID = new System.Windows.Forms.TextBox();
            this.tbOAStaffID = new System.Windows.Forms.TextBox();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tbOASuppID = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.inventoryIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invCostPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invQuantityAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.invDateAddedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inventoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btUpdateStatus = new System.Windows.Forms.Button();
            this.tbStatusUpdate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tafillOrdersTable = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderTableAdapter();
            this.tafillOrderItemsTable = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderItemTableAdapter();
            this.taAddOrderItem = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderItemTableAdapter();
            this.taAddOrder = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderTableAdapter();
            this.inventoryTableAdapter = new ISTN3ASGroup12Project.group12DataSetTableAdapters.InventoryTableAdapter();
            this.taCostUpdate = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderTableAdapter();
            this.taStatusUpdate = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderTableAdapter();
            this.taSeachItem = new ISTN3ASGroup12Project.group12DataSetTableAdapters.InventoryTableAdapter();
            this.taUpdateQuantity = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierOrderItemTableAdapter();
            this.taINVUpdate = new ISTN3ASGroup12Project.group12DataSetTableAdapters.InventoryTableAdapter();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.supplierIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppCellNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.group12DataSet = new ISTN3ASGroup12Project.group12DataSet();
            this.supplierTableAdapter = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierTableAdapter();
            this.taSearchSupplier = new ISTN3ASGroup12Project.group12DataSetTableAdapters.SupplierTableAdapter();
            this.dsSupplier = new ISTN3ASGroup12Project.group12DataSet();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip4 = new System.Windows.Forms.ToolTip(this.components);
            this.employeeTableAdapter = new ISTN3ASGroup12Project.group12DataSetTableAdapters.EmployeeTableAdapter();
            this.gbOrders.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierOrderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSupplierOrder)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierOrderItemBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSupplier)).BeginInit();
            this.SuspendLayout();
            // 
            // gbOrders
            // 
            this.gbOrders.Controls.Add(this.dataGridView1);
            this.gbOrders.Location = new System.Drawing.Point(9, 10);
            this.gbOrders.Margin = new System.Windows.Forms.Padding(2);
            this.gbOrders.Name = "gbOrders";
            this.gbOrders.Padding = new System.Windows.Forms.Padding(2);
            this.gbOrders.Size = new System.Drawing.Size(1068, 258);
            this.gbOrders.TabIndex = 0;
            this.gbOrders.TabStop = false;
            this.gbOrders.Text = "SUPPLIER ORDERS";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SuppOrderID,
            this.supplierIDDataGridViewTextBoxColumn,
            this.employeeIDDataGridViewTextBoxColumn,
            this.dateOrderedDataGridViewTextBoxColumn,
            this.orderTotalDataGridViewTextBoxColumn,
            this.statusDataGridViewCheckBoxColumn});
            this.dataGridView1.DataSource = this.supplierOrderBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(32, 17);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1031, 115);
            this.dataGridView1.TabIndex = 0;
            // 
            // SuppOrderID
            // 
            this.SuppOrderID.DataPropertyName = "SuppOrderID";
            this.SuppOrderID.HeaderText = "SuppOrderID";
            this.SuppOrderID.Name = "SuppOrderID";
            this.SuppOrderID.ReadOnly = true;
            // 
            // supplierIDDataGridViewTextBoxColumn
            // 
            this.supplierIDDataGridViewTextBoxColumn.DataPropertyName = "SupplierID";
            this.supplierIDDataGridViewTextBoxColumn.HeaderText = "SupplierID";
            this.supplierIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplierIDDataGridViewTextBoxColumn.Name = "supplierIDDataGridViewTextBoxColumn";
            this.supplierIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // employeeIDDataGridViewTextBoxColumn
            // 
            this.employeeIDDataGridViewTextBoxColumn.DataPropertyName = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.HeaderText = "EmployeeID";
            this.employeeIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.employeeIDDataGridViewTextBoxColumn.Name = "employeeIDDataGridViewTextBoxColumn";
            this.employeeIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.employeeIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // dateOrderedDataGridViewTextBoxColumn
            // 
            this.dateOrderedDataGridViewTextBoxColumn.DataPropertyName = "DateOrdered";
            this.dateOrderedDataGridViewTextBoxColumn.HeaderText = "DateOrdered";
            this.dateOrderedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dateOrderedDataGridViewTextBoxColumn.Name = "dateOrderedDataGridViewTextBoxColumn";
            this.dateOrderedDataGridViewTextBoxColumn.Width = 125;
            // 
            // orderTotalDataGridViewTextBoxColumn
            // 
            this.orderTotalDataGridViewTextBoxColumn.DataPropertyName = "OrderTotal";
            this.orderTotalDataGridViewTextBoxColumn.HeaderText = "OrderTotal";
            this.orderTotalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.orderTotalDataGridViewTextBoxColumn.Name = "orderTotalDataGridViewTextBoxColumn";
            this.orderTotalDataGridViewTextBoxColumn.Width = 125;
            // 
            // statusDataGridViewCheckBoxColumn
            // 
            this.statusDataGridViewCheckBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewCheckBoxColumn.HeaderText = "Status";
            this.statusDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.statusDataGridViewCheckBoxColumn.Name = "statusDataGridViewCheckBoxColumn";
            this.statusDataGridViewCheckBoxColumn.Width = 125;
            // 
            // supplierOrderBindingSource
            // 
            this.supplierOrderBindingSource.DataMember = "SupplierOrder";
            this.supplierOrderBindingSource.DataSource = this.dsSupplierOrder;
            this.supplierOrderBindingSource.CurrentChanged += new System.EventHandler(this.supplierOrderBindingSource_CurrentChanged);
            // 
            // dsSupplierOrder
            // 
            this.dsSupplierOrder.DataSetName = "group12DataSet";
            this.dsSupplierOrder.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Location = new System.Drawing.Point(8, 141);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(1070, 161);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SUPPLIER ORDER ITEMS";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.suppOrderItemIDDataGridViewTextBoxColumn,
            this.suppOrderIDDataGridViewTextBoxColumn1,
            this.inventoryIDDataGridViewTextBoxColumn,
            this.orderQuantityDataGridViewTextBoxColumn,
            this.costPerUnitDataGridViewTextBoxColumn,
            this.itemNameDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.supplierOrderItemBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(37, 19);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1028, 125);
            this.dataGridView2.TabIndex = 0;
            // 
            // suppOrderItemIDDataGridViewTextBoxColumn
            // 
            this.suppOrderItemIDDataGridViewTextBoxColumn.DataPropertyName = "SuppOrderItemID";
            this.suppOrderItemIDDataGridViewTextBoxColumn.HeaderText = "SuppOrderItemID";
            this.suppOrderItemIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.suppOrderItemIDDataGridViewTextBoxColumn.Name = "suppOrderItemIDDataGridViewTextBoxColumn";
            this.suppOrderItemIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // suppOrderIDDataGridViewTextBoxColumn1
            // 
            this.suppOrderIDDataGridViewTextBoxColumn1.DataPropertyName = "SuppOrderID";
            this.suppOrderIDDataGridViewTextBoxColumn1.HeaderText = "SuppOrderID";
            this.suppOrderIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.suppOrderIDDataGridViewTextBoxColumn1.Name = "suppOrderIDDataGridViewTextBoxColumn1";
            this.suppOrderIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // inventoryIDDataGridViewTextBoxColumn
            // 
            this.inventoryIDDataGridViewTextBoxColumn.DataPropertyName = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn.HeaderText = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.inventoryIDDataGridViewTextBoxColumn.Name = "inventoryIDDataGridViewTextBoxColumn";
            this.inventoryIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.inventoryIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // orderQuantityDataGridViewTextBoxColumn
            // 
            this.orderQuantityDataGridViewTextBoxColumn.DataPropertyName = "OrderQuantity";
            this.orderQuantityDataGridViewTextBoxColumn.HeaderText = "OrderQuantity";
            this.orderQuantityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.orderQuantityDataGridViewTextBoxColumn.Name = "orderQuantityDataGridViewTextBoxColumn";
            this.orderQuantityDataGridViewTextBoxColumn.Width = 125;
            // 
            // costPerUnitDataGridViewTextBoxColumn
            // 
            this.costPerUnitDataGridViewTextBoxColumn.DataPropertyName = "CostPerUnit";
            this.costPerUnitDataGridViewTextBoxColumn.HeaderText = "CostPerUnit";
            this.costPerUnitDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.costPerUnitDataGridViewTextBoxColumn.Name = "costPerUnitDataGridViewTextBoxColumn";
            this.costPerUnitDataGridViewTextBoxColumn.Width = 125;
            // 
            // itemNameDataGridViewTextBoxColumn
            // 
            this.itemNameDataGridViewTextBoxColumn.DataPropertyName = "ItemName";
            this.itemNameDataGridViewTextBoxColumn.HeaderText = "ItemName";
            this.itemNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.itemNameDataGridViewTextBoxColumn.Name = "itemNameDataGridViewTextBoxColumn";
            this.itemNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // supplierOrderItemBindingSource
            // 
            this.supplierOrderItemBindingSource.DataMember = "SupplierOrderItem";
            this.supplierOrderItemBindingSource.DataSource = this.dsSupplierOrder;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.tbOrderComplete);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.btOIAdd);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btOrderComplete);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.btAddOrder);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.tbOIACostPerUnit);
            this.groupBox2.Controls.Add(this.tbOIASuppOrderID);
            this.groupBox2.Controls.Add(this.tbOIAQuantity);
            this.groupBox2.Controls.Add(this.tbOIAItemName);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.labeOASuppID);
            this.groupBox2.Controls.Add(this.tbOIAInvID);
            this.groupBox2.Controls.Add(this.tbOAStaffID);
            this.groupBox2.Controls.Add(this.tbOASuppID);
            this.groupBox2.Location = new System.Drawing.Point(8, 628);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(1060, 119);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ADD ORDER";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(646, 80);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 22);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 22;
            this.pictureBox3.TabStop = false;
            this.toolTip3.SetToolTip(this.pictureBox3, "Enter Supplier Order ID Of Current Order And Confirm");
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1016, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 22);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 21;
            this.pictureBox2.TabStop = false;
            this.toolTip2.SetToolTip(this.pictureBox2, "Add Item to Supplier Order, One At A Time");
            // 
            // tbOrderComplete
            // 
            this.tbOrderComplete.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOrderComplete.Location = new System.Drawing.Point(376, 82);
            this.tbOrderComplete.Margin = new System.Windows.Forms.Padding(2);
            this.tbOrderComplete.Name = "tbOrderComplete";
            this.tbOrderComplete.Size = new System.Drawing.Size(110, 20);
            this.tbOrderComplete.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(215, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "ENTER SUPPLIER ORDER ID:";
            // 
            // btOIAdd
            // 
            this.btOIAdd.BackColor = System.Drawing.Color.BurlyWood;
            this.btOIAdd.Location = new System.Drawing.Point(898, 62);
            this.btOIAdd.Margin = new System.Windows.Forms.Padding(2);
            this.btOIAdd.Name = "btOIAdd";
            this.btOIAdd.Size = new System.Drawing.Size(113, 29);
            this.btOIAdd.TabIndex = 15;
            this.btOIAdd.Text = "ADD ORDER ITEM";
            this.btOIAdd.UseVisualStyleBackColor = false;
            this.btOIAdd.Click += new System.EventHandler(this.btOIAdd_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(788, 36);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "ENTER ITEM NAME:";
            // 
            // btOrderComplete
            // 
            this.btOrderComplete.BackColor = System.Drawing.Color.BurlyWood;
            this.btOrderComplete.Location = new System.Drawing.Point(501, 82);
            this.btOrderComplete.Margin = new System.Windows.Forms.Padding(2);
            this.btOrderComplete.Name = "btOrderComplete";
            this.btOrderComplete.Size = new System.Drawing.Size(140, 22);
            this.btOrderComplete.TabIndex = 16;
            this.btOrderComplete.Text = "ORDER COMPLETE";
            this.btOrderComplete.UseVisualStyleBackColor = false;
            this.btOrderComplete.Click += new System.EventHandler(this.btOrderComplete_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(765, 15);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "ENTER COST PER UNIT:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(520, 54);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "ENTER QUANTITY:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(498, 33);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "ENTER INVENTORY ID:";
            // 
            // btAddOrder
            // 
            this.btAddOrder.BackColor = System.Drawing.Color.BurlyWood;
            this.btAddOrder.Location = new System.Drawing.Point(118, 62);
            this.btAddOrder.Margin = new System.Windows.Forms.Padding(2);
            this.btAddOrder.Name = "btAddOrder";
            this.btAddOrder.Size = new System.Drawing.Size(98, 23);
            this.btAddOrder.TabIndex = 5;
            this.btAddOrder.Text = "ADD ORDER";
            this.btAddOrder.UseVisualStyleBackColor = false;
            this.btAddOrder.Click += new System.EventHandler(this.btAddOrder_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(466, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "ENTER SUPPLIER ORDER ID:";
            // 
            // tbOIACostPerUnit
            // 
            this.tbOIACostPerUnit.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOIACostPerUnit.Location = new System.Drawing.Point(902, 11);
            this.tbOIACostPerUnit.Margin = new System.Windows.Forms.Padding(2);
            this.tbOIACostPerUnit.Name = "tbOIACostPerUnit";
            this.tbOIACostPerUnit.ReadOnly = true;
            this.tbOIACostPerUnit.Size = new System.Drawing.Size(110, 20);
            this.tbOIACostPerUnit.TabIndex = 9;
            // 
            // tbOIASuppOrderID
            // 
            this.tbOIASuppOrderID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOIASuppOrderID.Location = new System.Drawing.Point(629, 8);
            this.tbOIASuppOrderID.Margin = new System.Windows.Forms.Padding(2);
            this.tbOIASuppOrderID.Name = "tbOIASuppOrderID";
            this.tbOIASuppOrderID.Size = new System.Drawing.Size(110, 20);
            this.tbOIASuppOrderID.TabIndex = 8;
            this.tbOIASuppOrderID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOIASuppOrderID_KeyPress_1);
            // 
            // tbOIAQuantity
            // 
            this.tbOIAQuantity.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOIAQuantity.Location = new System.Drawing.Point(629, 54);
            this.tbOIAQuantity.Margin = new System.Windows.Forms.Padding(2);
            this.tbOIAQuantity.Name = "tbOIAQuantity";
            this.tbOIAQuantity.Size = new System.Drawing.Size(110, 20);
            this.tbOIAQuantity.TabIndex = 7;
            this.tbOIAQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOIAQuantity_KeyPress_1);
            // 
            // tbOIAItemName
            // 
            this.tbOIAItemName.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOIAItemName.Location = new System.Drawing.Point(902, 33);
            this.tbOIAItemName.Margin = new System.Windows.Forms.Padding(2);
            this.tbOIAItemName.Name = "tbOIAItemName";
            this.tbOIAItemName.ReadOnly = true;
            this.tbOIAItemName.Size = new System.Drawing.Size(110, 20);
            this.tbOIAItemName.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 37);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "ENTER EMPLOYEE ID:";
            // 
            // labeOASuppID
            // 
            this.labeOASuppID.AutoSize = true;
            this.labeOASuppID.Location = new System.Drawing.Point(75, 15);
            this.labeOASuppID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labeOASuppID.Name = "labeOASuppID";
            this.labeOASuppID.Size = new System.Drawing.Size(117, 13);
            this.labeOASuppID.TabIndex = 3;
            this.labeOASuppID.Text = "ENTER SUPPLIER ID:";
            // 
            // tbOIAInvID
            // 
            this.tbOIAInvID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOIAInvID.Location = new System.Drawing.Point(629, 31);
            this.tbOIAInvID.Margin = new System.Windows.Forms.Padding(2);
            this.tbOIAInvID.Name = "tbOIAInvID";
            this.tbOIAInvID.ReadOnly = true;
            this.tbOIAInvID.Size = new System.Drawing.Size(110, 20);
            this.tbOIAInvID.TabIndex = 2;
            this.tbOIAInvID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOIAInvID_KeyPress_1);
            // 
            // tbOAStaffID
            // 
            this.tbOAStaffID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOAStaffID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "EmployeeID", true));
            this.tbOAStaffID.Location = new System.Drawing.Point(196, 37);
            this.tbOAStaffID.Margin = new System.Windows.Forms.Padding(2);
            this.tbOAStaffID.Name = "tbOAStaffID";
            this.tbOAStaffID.ReadOnly = true;
            this.tbOAStaffID.Size = new System.Drawing.Size(110, 20);
            this.tbOAStaffID.TabIndex = 1;
            this.tbOAStaffID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOAStaffID_KeyPress_1);
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.dsSupplierOrder;
            // 
            // tbOASuppID
            // 
            this.tbOASuppID.BackColor = System.Drawing.Color.BurlyWood;
            this.tbOASuppID.Location = new System.Drawing.Point(196, 15);
            this.tbOASuppID.Margin = new System.Windows.Forms.Padding(2);
            this.tbOASuppID.Name = "tbOASuppID";
            this.tbOASuppID.Size = new System.Drawing.Size(110, 20);
            this.tbOASuppID.TabIndex = 0;
            this.tbOASuppID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbOASuppID_KeyPress_1);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBox1);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.dataGridView3);
            this.groupBox3.Location = new System.Drawing.Point(8, 306);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(1066, 146);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "SEARCH INVENTORY";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(671, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox1, "Search For Item To Add To Supplier Order");
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(377, 15);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "SEARCH INVENTORY NAME:";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.BurlyWood;
            this.textBox1.Location = new System.Drawing.Point(550, 11);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(116, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.inventoryIDDataGridViewTextBoxColumn1,
            this.invNameDataGridViewTextBoxColumn,
            this.invCostPriceDataGridViewTextBoxColumn,
            this.invQuantityAvailableDataGridViewTextBoxColumn,
            this.invDescriptionDataGridViewTextBoxColumn,
            this.invDateAddedDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.inventoryBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(22, 33);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(1040, 98);
            this.dataGridView3.TabIndex = 0;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            this.dataGridView3.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentDoubleClick);
            // 
            // inventoryIDDataGridViewTextBoxColumn1
            // 
            this.inventoryIDDataGridViewTextBoxColumn1.DataPropertyName = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn1.HeaderText = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.inventoryIDDataGridViewTextBoxColumn1.Name = "inventoryIDDataGridViewTextBoxColumn1";
            this.inventoryIDDataGridViewTextBoxColumn1.ReadOnly = true;
            this.inventoryIDDataGridViewTextBoxColumn1.Width = 125;
            // 
            // invNameDataGridViewTextBoxColumn
            // 
            this.invNameDataGridViewTextBoxColumn.DataPropertyName = "invName";
            this.invNameDataGridViewTextBoxColumn.HeaderText = "invName";
            this.invNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.invNameDataGridViewTextBoxColumn.Name = "invNameDataGridViewTextBoxColumn";
            this.invNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // invCostPriceDataGridViewTextBoxColumn
            // 
            this.invCostPriceDataGridViewTextBoxColumn.DataPropertyName = "invCostPrice";
            this.invCostPriceDataGridViewTextBoxColumn.HeaderText = "invCostPrice";
            this.invCostPriceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.invCostPriceDataGridViewTextBoxColumn.Name = "invCostPriceDataGridViewTextBoxColumn";
            this.invCostPriceDataGridViewTextBoxColumn.Width = 125;
            // 
            // invQuantityAvailableDataGridViewTextBoxColumn
            // 
            this.invQuantityAvailableDataGridViewTextBoxColumn.DataPropertyName = "invQuantityAvailable";
            this.invQuantityAvailableDataGridViewTextBoxColumn.HeaderText = "invQuantityAvailable";
            this.invQuantityAvailableDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.invQuantityAvailableDataGridViewTextBoxColumn.Name = "invQuantityAvailableDataGridViewTextBoxColumn";
            this.invQuantityAvailableDataGridViewTextBoxColumn.Width = 125;
            // 
            // invDescriptionDataGridViewTextBoxColumn
            // 
            this.invDescriptionDataGridViewTextBoxColumn.DataPropertyName = "invDescription";
            this.invDescriptionDataGridViewTextBoxColumn.HeaderText = "invDescription";
            this.invDescriptionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.invDescriptionDataGridViewTextBoxColumn.Name = "invDescriptionDataGridViewTextBoxColumn";
            this.invDescriptionDataGridViewTextBoxColumn.Width = 125;
            // 
            // invDateAddedDataGridViewTextBoxColumn
            // 
            this.invDateAddedDataGridViewTextBoxColumn.DataPropertyName = "invDateAdded";
            this.invDateAddedDataGridViewTextBoxColumn.HeaderText = "invDateAdded";
            this.invDateAddedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.invDateAddedDataGridViewTextBoxColumn.Name = "invDateAddedDataGridViewTextBoxColumn";
            this.invDateAddedDataGridViewTextBoxColumn.Width = 125;
            // 
            // inventoryBindingSource
            // 
            this.inventoryBindingSource.DataMember = "Inventory";
            this.inventoryBindingSource.DataSource = this.dsSupplierOrder;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pictureBox4);
            this.groupBox4.Controls.Add(this.btUpdateStatus);
            this.groupBox4.Controls.Add(this.tbStatusUpdate);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Location = new System.Drawing.Point(8, 751);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(1060, 59);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "UPDATE STATUS";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(671, 23);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(32, 22);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 23;
            this.pictureBox4.TabStop = false;
            this.toolTip4.SetToolTip(this.pictureBox4, "Enter Supplier Order ID of Received Order And Press To Confirm");
            // 
            // btUpdateStatus
            // 
            this.btUpdateStatus.BackColor = System.Drawing.Color.BurlyWood;
            this.btUpdateStatus.Location = new System.Drawing.Point(569, 23);
            this.btUpdateStatus.Margin = new System.Windows.Forms.Padding(2);
            this.btUpdateStatus.Name = "btUpdateStatus";
            this.btUpdateStatus.Size = new System.Drawing.Size(86, 22);
            this.btUpdateStatus.TabIndex = 17;
            this.btUpdateStatus.Text = "RECEIVED";
            this.btUpdateStatus.UseVisualStyleBackColor = false;
            this.btUpdateStatus.Click += new System.EventHandler(this.btUpdateStatus_Click);
            // 
            // tbStatusUpdate
            // 
            this.tbStatusUpdate.BackColor = System.Drawing.Color.BurlyWood;
            this.tbStatusUpdate.Location = new System.Drawing.Point(442, 25);
            this.tbStatusUpdate.Margin = new System.Windows.Forms.Padding(2);
            this.tbStatusUpdate.Name = "tbStatusUpdate";
            this.tbStatusUpdate.Size = new System.Drawing.Size(110, 20);
            this.tbStatusUpdate.TabIndex = 12;
            this.tbStatusUpdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStatusUpdate_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(278, 25);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(159, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "ENTER SUPPLIER ORDER ID:";
            // 
            // tafillOrdersTable
            // 
            this.tafillOrdersTable.ClearBeforeFill = true;
            // 
            // tafillOrderItemsTable
            // 
            this.tafillOrderItemsTable.ClearBeforeFill = true;
            // 
            // taAddOrderItem
            // 
            this.taAddOrderItem.ClearBeforeFill = true;
            // 
            // taAddOrder
            // 
            this.taAddOrder.ClearBeforeFill = true;
            // 
            // inventoryTableAdapter
            // 
            this.inventoryTableAdapter.ClearBeforeFill = true;
            // 
            // taCostUpdate
            // 
            this.taCostUpdate.ClearBeforeFill = true;
            // 
            // taStatusUpdate
            // 
            this.taStatusUpdate.ClearBeforeFill = true;
            // 
            // taSeachItem
            // 
            this.taSeachItem.ClearBeforeFill = true;
            // 
            // taUpdateQuantity
            // 
            this.taUpdateQuantity.ClearBeforeFill = true;
            // 
            // taINVUpdate
            // 
            this.taINVUpdate.ClearBeforeFill = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dataGridView4);
            this.groupBox5.Location = new System.Drawing.Point(9, 457);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1064, 166);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "SUPPLIER INFORMATION";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplierIDDataGridViewTextBoxColumn1,
            this.suppNameDataGridViewTextBoxColumn,
            this.suppCellNoDataGridViewTextBoxColumn,
            this.suppAddressDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.supplierBindingSource;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView4.Location = new System.Drawing.Point(3, 16);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1058, 147);
            this.dataGridView4.TabIndex = 0;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            // 
            // supplierIDDataGridViewTextBoxColumn1
            // 
            this.supplierIDDataGridViewTextBoxColumn1.DataPropertyName = "SupplierID";
            this.supplierIDDataGridViewTextBoxColumn1.HeaderText = "SupplierID";
            this.supplierIDDataGridViewTextBoxColumn1.Name = "supplierIDDataGridViewTextBoxColumn1";
            this.supplierIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // suppNameDataGridViewTextBoxColumn
            // 
            this.suppNameDataGridViewTextBoxColumn.DataPropertyName = "suppName";
            this.suppNameDataGridViewTextBoxColumn.HeaderText = "suppName";
            this.suppNameDataGridViewTextBoxColumn.Name = "suppNameDataGridViewTextBoxColumn";
            // 
            // suppCellNoDataGridViewTextBoxColumn
            // 
            this.suppCellNoDataGridViewTextBoxColumn.DataPropertyName = "suppCellNo";
            this.suppCellNoDataGridViewTextBoxColumn.HeaderText = "suppCellNo";
            this.suppCellNoDataGridViewTextBoxColumn.Name = "suppCellNoDataGridViewTextBoxColumn";
            // 
            // suppAddressDataGridViewTextBoxColumn
            // 
            this.suppAddressDataGridViewTextBoxColumn.DataPropertyName = "suppAddress";
            this.suppAddressDataGridViewTextBoxColumn.HeaderText = "suppAddress";
            this.suppAddressDataGridViewTextBoxColumn.Name = "suppAddressDataGridViewTextBoxColumn";
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.group12DataSet;
            // 
            // group12DataSet
            // 
            this.group12DataSet.DataSetName = "group12DataSet";
            this.group12DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // taSearchSupplier
            // 
            this.taSearchSupplier.ClearBeforeFill = true;
            // 
            // dsSupplier
            // 
            this.dsSupplier.DataSetName = "group12DataSet";
            this.dsSupplier.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // ORDER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1406, 836);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbOrders);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ORDER";
            this.Text = "SUPPLIER ORDER";
            this.Load += new System.EventHandler(this.ORDER_Load);
            this.gbOrders.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierOrderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSupplierOrder)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierOrderItemBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventoryBindingSource)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.group12DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSupplier)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbOrders;
        private System.Windows.Forms.DataGridView dataGridView1;
        private group12DataSet dsSupplierOrder;
        private System.Windows.Forms.BindingSource supplierOrderBindingSource;
        private group12DataSetTableAdapters.SupplierOrderTableAdapter tafillOrdersTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppOrderIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateReceivedDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource supplierOrderItemBindingSource;
        private group12DataSetTableAdapters.SupplierOrderItemTableAdapter tafillOrderItemsTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppOrderItemIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppOrderIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn costPerUnitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btAddOrder;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labeOASuppID;
        private System.Windows.Forms.TextBox tbOIAInvID;
        private System.Windows.Forms.TextBox tbOAStaffID;
        private System.Windows.Forms.TextBox tbOASuppID;
        private System.Windows.Forms.TextBox tbOIAQuantity;
        private System.Windows.Forms.TextBox tbOIAItemName;
        private System.Windows.Forms.Button btOIAdd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbOIACostPerUnit;
        private System.Windows.Forms.TextBox tbOIASuppOrderID;
        private group12DataSetTableAdapters.SupplierOrderItemTableAdapter taAddOrderItem;
        private System.Windows.Forms.Button btOrderComplete;
        private group12DataSetTableAdapters.SupplierOrderTableAdapter taAddOrder;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource inventoryBindingSource;
        private group12DataSetTableAdapters.InventoryTableAdapter inventoryTableAdapter;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private group12DataSetTableAdapters.SupplierOrderTableAdapter taCostUpdate;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btUpdateStatus;
        private System.Windows.Forms.TextBox tbStatusUpdate;
        private System.Windows.Forms.Label label8;
        private group12DataSetTableAdapters.SupplierOrderTableAdapter taStatusUpdate;
        private group12DataSetTableAdapters.InventoryTableAdapter taSeachItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn SuppOrderID;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn employeeIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateOrderedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderTotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn statusDataGridViewCheckBoxColumn;
        private System.Windows.Forms.TextBox tbOrderComplete;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn invNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invCostPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invQuantityAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn invDateAddedDataGridViewTextBoxColumn;
        private group12DataSetTableAdapters.SupplierOrderItemTableAdapter taUpdateQuantity;
        private group12DataSetTableAdapters.InventoryTableAdapter taINVUpdate;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView4;
        private group12DataSet group12DataSet;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private group12DataSetTableAdapters.SupplierTableAdapter supplierTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppCellNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn suppAddressDataGridViewTextBoxColumn;
        private group12DataSetTableAdapters.SupplierTableAdapter taSearchSupplier;
        private group12DataSet dsSupplier;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.ToolTip toolTip3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.ToolTip toolTip4;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private group12DataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
    }
}