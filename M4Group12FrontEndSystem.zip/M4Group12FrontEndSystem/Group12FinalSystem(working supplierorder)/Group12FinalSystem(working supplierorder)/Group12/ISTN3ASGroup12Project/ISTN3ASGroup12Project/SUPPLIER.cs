﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class SUPPLIER : Form
    {
        public SUPPLIER()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            taSupplier.Fill(dsSupplier.Supplier);
        }

        private void Supplier_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Supplier' table. You can move, or remove it, as needed.
            this.taSupplier.Fill(this.dsSupplier.Supplier);

        }

        private void tbSupplierSearch_TextChanged(object sender, EventArgs e)
        {
            taSupplierSearch.FillBySuppSearch(dsSupplier.Supplier, tbSupplierSearch.Text);
        }

        private void btAddSupp_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add supplier?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                if (tbSuppCellNo.Text.Length == 10 && tbSuppPostalCode.Text.Length == 4 && (tbSuppAddress.Text.Contains("@gmail.com") == true))
                {
                    try
                    {
                        taAddSupplier.AddSupplier(tbSuppName.Text, tbSuppCellNo.Text, tbSuppAddress.Text,
                        tbSuppPostalCode.Text);
                        MessageBox.Show("Supplier added to database, reload page to view changes.");
                    }
                    catch
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
                else
                {
                    if (tbSuppCellNo.Text.Length < 10 && tbSuppCellNo.Text != "")
                    {
                        MessageBox.Show("Invalid Cellphone number", "Error");
                    }
                    if (tbSuppPostalCode.Text.Length < 4 && tbSuppPostalCode.Text != "")
                    {
                        MessageBox.Show("Invalid postal code", "Error");
                    }
                    if ((tbSuppAddress.Text.Contains("@gmail.com") == false) && tbSuppAddress.Text != "")
                    {
                        MessageBox.Show("Invalid email address", "Error");
                    }
                    if (tbSuppName.Text != "" || tbSuppAddress.Text != "" || tbSuppCellNo.Text != "" || tbSuppPostalCode.Text != "")
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbSuppName.Text = ""; tbSuppCellNo.Text = ""; tbSuppAddress.Text = "";
            tbSuppPostalCode.Text = "";
        }
        private void tbSuppName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbSuppCellNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbSuppPostalCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbSuppName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbSuppCellNo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbSuppPostalCode_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
