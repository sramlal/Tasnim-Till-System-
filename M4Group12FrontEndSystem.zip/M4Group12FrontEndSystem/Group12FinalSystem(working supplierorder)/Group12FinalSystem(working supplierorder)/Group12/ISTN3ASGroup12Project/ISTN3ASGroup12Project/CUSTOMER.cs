﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class CUSTOMER : Form
    {
        public CUSTOMER()
        {
            InitializeComponent();
            taCustomer.Fill(dsCustomer.Customer);
        }

        private void CUSTOMER_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Customer' table. You can move, or remove it, as needed.
            this.taCustomer.Fill(this.dsCustomer.Customer);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbSearchCust_TextChanged(object sender, EventArgs e)
        {
            taSearchCust.FillByCustName(dsCustomer.Customer, tbSearchCust.Text);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btAddCust_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add customer?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                if ((tbACEmail.Text.Contains("@gmail.com") == true) && tbACCellNo.Text.Length == 10)
                {
                    try
                    {
                        taAddCust.AddCust(tbACName.Text, tbACLName.Text, tbACEmail.Text,
                        tbACCellNo.Text, tbACPassword.Text);
                        MessageBox.Show("Customer added to database, reload page to view changes.");
                    }
                    catch
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
                else
                {
                    if ((tbACEmail.Text.Contains("@gmail.com") == false) && tbACEmail.Text != "")
                    {
                        MessageBox.Show("Invalid Email", "Error");
                    }
                    if (tbACCellNo.Text.Length < 10 && tbACCellNo.Text != "")
                    {
                        MessageBox.Show("Invalid Cellphone number", "Error");
                    }
                    if (tbACCellNo.Text == "" || tbACEmail.Text == "" || tbACLName.Text == "" || tbACName.Text == "" || tbACPassword.Text == "")
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbACName.Text = ""; tbACLName.Text = ""; tbACEmail.Text = "";
            tbACCellNo.Text = ""; tbACPassword.Text = "";
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btUpdateCust_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update customer?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                if (tbUCCellNo.Text.Length == 10 && (tbUCEmail.Text.Contains("@gmail.com") == true))
                {
                    try
                    {
                        taUpdateCust.UpdateCust(tbUCCellNo.Text, tbUCPassword.Text, tbUCName.Text, tbUCLName.Text, tbUCEmail.Text);
                        MessageBox.Show("Customer updated on database, reload page to view changes");
                    }
                    catch
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
                else
                {
                    if (tbUCCellNo.Text.Length < 10 && tbUCCellNo.Text != "")
                    {
                        MessageBox.Show("Invalid Cellphone number", "Error");
                    }
                    if ((tbUCEmail.Text.Contains("@gmail") == false) && tbUCEmail.Text != "")
                    {
                        MessageBox.Show("Invalid email", "Error");
                    }
                    if (tbUCCellNo.Text == "" || tbUCEmail.Text == "" || tbUCLName.Text == "" || tbUCName.Text == "" || tbUCPassword.Text == "")
                    {
                        MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                    }
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbUCName.Text = ""; tbUCLName.Text = ""; tbUCEmail.Text = "";
            tbUCCellNo.Text = ""; tbUCPassword.Text = "";
        }

            private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void tbUCName_TextChanged(object sender, EventArgs e)
        {

        }
        private void tbACName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbACLName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbACCellNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUCCellNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbUCCellNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUCName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUCLName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbACName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbACLName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbACEmail_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbACCellNo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbACPassword_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbUCName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUCLName_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUCEmail_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbUCCellNo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbUCPassword_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
    }
}
