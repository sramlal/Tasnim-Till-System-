﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class INVENTORY_REPORT : Form
    {
        public INVENTORY_REPORT()
        {
            InitializeComponent();
        }

        private void INVENTORY_REPORT_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Inventory' table. You can move, or remove it, as needed.
            this.InventoryTableAdapter.Fill(this.group12DataSet.Inventory);

            // this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
            
        }
    }
}
