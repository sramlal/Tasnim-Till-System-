﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ISTN3ASGroup12Project
{
    public partial class INVENTORY : Form
    {
        public INVENTORY()
        {
            InitializeComponent();
            taInventoryDB.Fill(dsInventory.Inventory);
        }

        private void INVENTORY_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'group12DataSet.Inventory' table. You can move, or remove it, as needed.
            this.taInventoryDB.Fill(this.dsInventory.Inventory);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            taInvSearch.FillBySearchInv(dsInventory.Inventory, tbSearchInv.Text);
        }

        private void btInvAdd_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to add inventory item?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    DateTime now = DateTime.Now;
                    taAddInv.AddInv(tbAIName.Text, decimal.Parse(tbAISellingPrice.Text), decimal.Parse(tbAICostPrice.Text),
                    int.Parse(tbAIQuantity.Text), cbAIDescrip.Text.ToString(), now);
                    MessageBox.Show("Inventory added to database, reload page to view changes.");
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbAIName.Text = ""; tbAISellingPrice.Text = ""; tbAICostPrice.Text = "";
            tbAIQuantity.Text = ""; //tbAIDescrip.Text = ""; 
        }

        private void btUpdateInv_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to update inventory item?", "Confirmation", MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                try
                {
                    taUpdateInv.UpdateInv(decimal.Parse(tbIUSellingPrice.Text), decimal.Parse(tbIUCostPrice.Text),
                    int.Parse(tbIUQuantity.Text), tbIUName.Text);
                    MessageBox.Show("Inventory database updated, reload page to view changes.");
                }
                catch
                {
                    MessageBox.Show("Please enter sufficient data in textboxes", "Error");
                }
            }
            else
            {
                MessageBox.Show("Action cancelled");
            }
            tbIUSellingPrice.Text = ""; tbIUCostPrice.Text = "";
            tbIUQuantity.Text = ""; tbIUName.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void tbIUQuantity_TextChanged(object sender, EventArgs e)
        {

        }
        private void tbAISellingPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbAICostPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbAIQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbIUCostPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbIUSellingPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbIUQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbAIName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbAISellingPrice_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            
        }

        private void tbAICostPrice_KeyPress_1(object sender, KeyPressEventArgs e)
        {
           
        }

        private void tbAIQuantity_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tbIUName_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void tbIUQuantity_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
